"use strict";
(() => {
var exports = {};
exports.id = 51;
exports.ids = [51];
exports.modules = {

/***/ 4219:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ aboutUs),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(1377);
// EXTERNAL MODULE: external "next-i18next/serverSideTranslations"
var serverSideTranslations_ = __webpack_require__(5460);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./src/components/Basic/Button/index.tsx + 2 modules
var Button = __webpack_require__(9126);
// EXTERNAL MODULE: ./src/layout/Container/index.tsx
var Container = __webpack_require__(8219);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: ./i18n.js
var i18n = __webpack_require__(5558);
var i18n_default = /*#__PURE__*/__webpack_require__.n(i18n);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: external "axios"
const external_axios_namespaceObject = require("axios");
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_namespaceObject);
// EXTERNAL MODULE: ./src/components/Basic/Banner/Banner.tsx
var Banner = __webpack_require__(4103);
// EXTERNAL MODULE: external "@emotion/styled"
var styled_ = __webpack_require__(1480);
var styled_default = /*#__PURE__*/__webpack_require__.n(styled_);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./src/pages/aboutUs.tsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



 // constants
// Components














const Home = () => {
  const {
    t
  } = (0,external_next_i18next_.useTranslation)('common');
  const {
    0: priceCur,
    1: setPriceCur
  } = (0,external_react_.useState)('irt');
  const router = (0,router_.useRouter)();
  const matches = (0,material_.useMediaQuery)(theme => theme.breakpoints.up('lg'), {
    noSsr: true
  });
  const ultraLarge = (0,material_.useMediaQuery)('(min-width:3000px)', {
    noSsr: true
  });
  const {
    0: chartData,
    1: setChartData
  } = (0,external_react_.useState)();
  const {
    0: isOpen,
    1: setIsOpen
  } = (0,external_react_.useState)(false);
  const {
    0: url,
    1: setUrl
  } = (0,external_react_.useState)('');
  const {
    locale,
    query,
    asPath,
    pathname
  } = router;

  const api = async () => {
    const data = await external_axios_default().get('https://api.maxpool.ir/mainpage/binance-api/get-all-symbols-socket/', {
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      }
    });
    setChartData(data.data);
  };

  (0,external_react_.useEffect)(() => {
    api();
    setInterval(() => {
      api();
    }, 180000);
    return () => clearInterval();
  }, []);
  const tableCoin = ['BTC', 'ETH', 'TRX', 'BNB', 'USDT', 'SHIB'];
  const cardCoin = ['LINK', 'ADA', 'AAVE', 'DOT', 'BNB'];

  const onTetherClick = name => {
    setPriceCur(name);
  };

  const onDetailClick = () => {
    router.push('/pdp');
  };

  const video = ['https://www.aparat.com/video/video/embed/videohash/ohf1G/vt/frame', 'https://www.aparat.com/video/video/embed/videohash/7ZBp3/vt/frame', 'https://www.aparat.com/video/video/embed/videohash/qYC7h/vt/frame'];

  const onModalOpen = name => {
    video.map((item, index) => {
      if (name === index) {
        setIsOpen(true);
        setUrl(item);
      }
    });
  }; // test


  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    children: [/*#__PURE__*/jsx_runtime_.jsx((head_default()), {
      children: /*#__PURE__*/jsx_runtime_.jsx("title", {
        children: " dental"
      })
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Box, {
      component: "div",
      children: [/*#__PURE__*/jsx_runtime_.jsx(Banner/* default */.Z, {}), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Box, {
        sx: {
          height: '560px',
          position: 'absolute',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'flex-start',
          flexDirection: 'column',
          left: 0,
          right: 0,
          margin: '0 55px',
          top: '2vh'
        },
        children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
          variant: "h4",
          component: "h1",
          sx: {
            color: '#ffff',
            textAlign: 'left',
            fontWeight: '700',
            width: {
              xs: '50%',
              lg: '20%'
            }
          },
          children: "The Days Of Covering Your Smile Are Over"
        }), /*#__PURE__*/jsx_runtime_.jsx(Button/* default */.Z, {
          sx: {
            margin: '2% 0',
            borderRadius: '5px',
            backgroundColor: '#4252FA'
          },
          children: "Contact Us"
        })]
      })]
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Box, {
      sx: {
        marginTop: '65Vh',
        marginBottom: '100px',
        textAlign: 'center',
        color: '#323232'
      },
      children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
        variant: "h5",
        gutterBottom: true,
        component: "div",
        children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.Tempor nibh"
      }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
        variant: "h5",
        gutterBottom: true,
        component: "div",
        children: "eget pharetra ac bibendum elit."
      }), /*#__PURE__*/jsx_runtime_.jsx(Button/* default */.Z, {
        sx: {
          margin: '2% 0',
          borderRadius: '5px',
          backgroundColor: '#4252FA'
        },
        children: "Contact Us"
      })]
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(ContainerCom, {
      fixed: true,
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
        container: true,
        spacing: 2,
        children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
          item: true,
          xs: 12,
          md: 5,
          children: /*#__PURE__*/jsx_runtime_.jsx(ImgServis, {
            src: "/images/aboutUs/Rectangle109.png",
            alt: ""
          })
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
          item: true,
          xs: 12,
          md: 7,
          sx: {
            color: '#A3B5C4',
            fontWeight: '900'
          },
          children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
            variant: "h2",
            gutterBottom: true,
            component: "div",
            children: "Scalling"
          }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
            variant: "body1",
            gutterBottom: true,
            component: "div",
            sx: {
              width: '60%'
            },
            children: "If plaque and tartar is left on the teeth, it provides the right conditions for bacteria to thrive. The bacteria irritate the gums, which means that they bleed more easily. if you are brushing your teeth, or eating, and sometimes your gums may bleed a bit."
          })]
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
        container: true,
        spacing: 2,
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
          item: true,
          xs: 12,
          md: 7,
          sx: {
            color: '#A3B5C4',
            fontWeight: '900'
          },
          children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
            variant: "h2",
            gutterBottom: true,
            component: "div",
            children: "Teeth Whitening"
          }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
            variant: "body1",
            gutterBottom: true,
            component: "div",
            sx: {
              width: '60%'
            },
            children: "We can help you choose a whitening procedure that would be more effective for you.we may suggest a procedure that can be done in our office or we might even offer and provide you with several types of products that can be safely used at home to achieve stunning results."
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
          item: true,
          xs: 12,
          md: 5,
          children: /*#__PURE__*/jsx_runtime_.jsx(ImgServis, {
            src: "/images/aboutUs/2.png",
            alt: ""
          })
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
        container: true,
        spacing: 2,
        children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
          item: true,
          xs: 12,
          md: 5,
          children: /*#__PURE__*/jsx_runtime_.jsx(ImgServis, {
            src: "/images/aboutUs/Rectangle109.png",
            alt: ""
          })
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
          item: true,
          xs: 12,
          md: 7,
          sx: {
            color: '#A3B5C4',
            fontWeight: '900'
          },
          children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
            variant: "h2",
            gutterBottom: true,
            component: "div",
            children: "Desensitization"
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Typography, {
            variant: "body1",
            gutterBottom: true,
            component: "div",
            sx: {
              width: '60%'
            },
            children: ["Teeth can be sensitive to a number of things including hot or cold, touch, or sweets. When the gums recede the root is exposed and under certain conditions may become sensitive. Desensitization uses techniques to protect the tooth root from these stimuli.", ' ']
          })]
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
        container: true,
        spacing: 2,
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
          item: true,
          xs: 12,
          md: 7,
          sx: {
            color: '#A3B5C4',
            fontWeight: '900'
          },
          children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
            variant: "h2",
            gutterBottom: true,
            component: "div",
            children: "Sealants"
          }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
            variant: "body1",
            gutterBottom: true,
            component: "div",
            sx: {
              width: '60%'
            },
            children: "Sealants are a thin, plastic coating painted on the chewing surfaces of teeth -- usually the back teeth (the premolars, and molars) -- to prevent tooth decay. The painted on liquid sealant quickly bonds into the depressions and grooves of the teeth forming a protective shield over the enamel of each tooth, protect the teeth from decay."
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
          item: true,
          xs: 12,
          md: 5,
          children: /*#__PURE__*/jsx_runtime_.jsx(ImgServis, {
            src: "/images/aboutUs/Rectangle109.png",
            alt: ""
          })
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
        container: true,
        spacing: 2,
        children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
          item: true,
          xs: 12,
          md: 5,
          children: /*#__PURE__*/jsx_runtime_.jsx(ImgServis, {
            src: "/images/aboutUs/Rectangle109.png",
            alt: ""
          })
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
          item: true,
          xs: 12,
          md: 7,
          sx: {
            color: '#A3B5C4',
            fontWeight: '900'
          },
          children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
            variant: "h2",
            gutterBottom: true,
            component: "div",
            children: "Fluoride Treatment"
          }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
            variant: "body1",
            gutterBottom: true,
            component: "div",
            sx: {
              width: '60%'
            },
            children: "Tooth decay is caused by acid-producing bacteria that collect around the teeth and gingivae (gums) in a sticky, clear film called \u201Cplaque.\u201D Typically, it is applied with a cotton swab or brush, or it is used as a rinse or placed in a tray that is held in the mouth for several minutes."
          })]
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
        container: true,
        spacing: 2,
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
          item: true,
          xs: 12,
          md: 7,
          sx: {
            color: '#A3B5C4',
            fontWeight: '900'
          },
          children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
            variant: "h2",
            gutterBottom: true,
            component: "div",
            children: "Oral Cancer"
          }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
            variant: "body1",
            gutterBottom: true,
            component: "div",
            sx: {
              width: '60%'
            },
            children: "Detecting the disease in the early stages is key to the survival rate. Thousands of new cases of oral cancer are diagnosed in Canada each year; the five-year survival rate of all oral cancer cases is about 50 per cent. Some estimates suggest that screening could detect as many as 80 per cent of new cases."
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
          item: true,
          xs: 12,
          md: 5,
          children: /*#__PURE__*/jsx_runtime_.jsx(ImgServis, {
            src: "/images/aboutUs/Rectangle109.png",
            alt: ""
          })
        })]
      })]
    })]
  });
};

const ImgServis = (styled_default()).img`
  width: 100%;
  margin-top:-1% ;
`;
const ContainerCom = styled_default()(Container/* default */.Z)`
  line-height: 15;

`;
const ImgServises = (/* unused pure expression or super */ null && (styled(Grid)`
  background-image: url('/images/homePage/Servises1.png');
  background-size: cover;
  height: 450px;
  display: flex;
  flex-direction: column;
  align-content: flex-start;
  justify-content: flex-start;
  align-items: flex-start;
  color: #fff;
  background-color: #000;
  border-radius: 25px;
  font-size: 1.5rem;
  line-height: 2.5;
`));
const ImgServisesR = (/* unused pure expression or super */ null && (styled(Grid)`
  background-image: url('/images/homePage/Servises1.png');
  background-size: cover;
  height: 450px;
  display: flex;
  flex-direction: column;
  align-content: flex-end;
  justify-content: flex-end;
  align-items: flex-end;
  color: #fff;
  background-color: #000;
  border-radius: 25px;
  font-size: 1.5rem;
  line-height: 2.5;
`));
const BgBannerCenter = (/* unused pure expression or super */ null && (styled(Box)`
  background-image: url('/images/homePage/BgBannerCenter.png');
  background-size: cover;
  height: 368px;
  text-align: center;
  margin-bottom: 50px;
`));
const TypogerapyOnBanner = (/* unused pure expression or super */ null && (styled(Typography)`
  color: #fff;
  justify-content: center;
  display: flex;
  align-items: center;
  padding-top: 10%;
`));
const GoogleBox = (/* unused pure expression or super */ null && (styled(Typography)`
  margin-bottom: 50px;
  margin-top: 30px;
  border-bottom: 2px solid #000;
  width: fit-content;
`));
const BoxContentRevies = (/* unused pure expression or super */ null && (styled(Box)`
  background: #ffffff;
  box-shadow: 0px 0px 30px rgba(181, 181, 181, 0.25);
  border-radius: 25px;
  padding: 30px;
  a {
    color: #4060ff;
  }
`));
const getStaticProps = async ({
  locale
}) => {
  return {
    props: _objectSpread({
      locale
    }, await (0,serverSideTranslations_.serverSideTranslations)(locale, ['common'], (i18n_default())))
  };
};
/* harmony default export */ const aboutUs = (Home);

/***/ }),

/***/ 1480:
/***/ ((module) => {

module.exports = require("@emotion/styled");

/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 3819:
/***/ ((module) => {

module.exports = require("@mui/material/Button");

/***/ }),

/***/ 4475:
/***/ ((module) => {

module.exports = require("@mui/material/Container");

/***/ }),

/***/ 1635:
/***/ ((module) => {

module.exports = require("dayjs");

/***/ }),

/***/ 2764:
/***/ ((module) => {

module.exports = require("jalali-dayjs");

/***/ }),

/***/ 1377:
/***/ ((module) => {

module.exports = require("next-i18next");

/***/ }),

/***/ 5460:
/***/ ((module) => {

module.exports = require("next-i18next/serverSideTranslations");

/***/ }),

/***/ 8028:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3018:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 4417:
/***/ ((module) => {

module.exports = require("react-spring");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [639,675,558,126,219,103], () => (__webpack_exec__(4219)));
module.exports = __webpack_exports__;

})();