"use strict";
(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 9376:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ pages),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(1377);
// EXTERNAL MODULE: external "next-i18next/serverSideTranslations"
var serverSideTranslations_ = __webpack_require__(5460);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./src/components/Basic/Button/index.tsx + 2 modules
var Button = __webpack_require__(9126);
// EXTERNAL MODULE: ./src/layout/Container/index.tsx
var layout_Container = __webpack_require__(8219);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: ./i18n.js
var i18n = __webpack_require__(5558);
var i18n_default = /*#__PURE__*/__webpack_require__.n(i18n);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./src/components/Basic/Banner/Banner.tsx
var Banner = __webpack_require__(4103);
// EXTERNAL MODULE: external "@emotion/styled"
var styled_ = __webpack_require__(1480);
var styled_default = /*#__PURE__*/__webpack_require__.n(styled_);
;// CONCATENATED MODULE: external "@mui/icons-material/ArrowForwardIos"
const ArrowForwardIos_namespaceObject = require("@mui/icons-material/ArrowForwardIos");
var ArrowForwardIos_default = /*#__PURE__*/__webpack_require__.n(ArrowForwardIos_namespaceObject);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./src/pages/index.tsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



 // constants
// Components














const Home = () => {
  const {
    t
  } = (0,external_next_i18next_.useTranslation)('common');
  const {
    0: priceCur,
    1: setPriceCur
  } = (0,external_react_.useState)('irt');
  const router = (0,router_.useRouter)();
  const matches = (0,material_.useMediaQuery)(theme => theme.breakpoints.up('lg'), {
    noSsr: true
  });
  const ultraLarge = (0,material_.useMediaQuery)('(min-width:3000px)', {
    noSsr: true
  }); // test

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    children: [/*#__PURE__*/jsx_runtime_.jsx((head_default()), {
      children: /*#__PURE__*/jsx_runtime_.jsx("title", {
        children: "Dental"
      })
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Box, {
      component: "div",
      children: [/*#__PURE__*/jsx_runtime_.jsx(Banner/* default */.Z, {}), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Box, {
        sx: {
          height: '560px',
          position: 'absolute',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'flex-start',
          flexDirection: 'column',
          left: 0,
          right: 0,
          margin: '0 55px',
          top: '2vh'
        },
        children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
          variant: "h3",
          sx: {
            color: '#fff',
            fontWeight: '700'
          },
          gutterBottom: true,
          component: "div",
          children: "The Days Of Covering"
        }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
          sx: {
            color: '#fff',
            fontWeight: '700'
          },
          variant: "h3",
          gutterBottom: true,
          component: "div",
          children: "Your Smile Are Over"
        }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
          sx: {
            color: '#fff',
            fontWeight: '700',
            marginBottom: '50px'
          },
          variant: "h5",
          gutterBottom: true,
          component: "div",
          children: "Trust A&E Dental Services"
        }), /*#__PURE__*/jsx_runtime_.jsx(Button/* default */.Z, {
          children: 'Contact Us'
        })]
      })]
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(layout_Container/* default */.Z, {
      sx: {
        marginTop: {
          xs: '10vh',
          md: '72vh'
        }
      },
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
        sx: {
          alignItems: 'center',
          marginBottom: '100px'
        },
        container: true,
        spacing: 2,
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
          item: true,
          xs: 12,
          md: 6,
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
            children: [/*#__PURE__*/jsx_runtime_.jsx(RubikTiitle, {
              sx: {
                marginBottom: '-8%',
                color: '#DCDCDC'
              },
              variant: "h1",
              gutterBottom: true,
              children: "Welcome"
            }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
              sx: {
                color: '#476B8A',
                fontWeight: '700'
              },
              variant: "h3",
              gutterBottom: true,
              component: "div",
              children: "To A&E Clinic"
            })]
          }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
            sx: {
              color: '#343434'
            },
            variant: "body1",
            gutterBottom: true,
            component: "div",
            children: "With years of professional experience and extensive insight into preventative measures for better dental health, we offer general and cosmetic dental services to the community with utmost care and affordable rates. Like many dental health practitioners, we firmly believe that preventative care is a key component of obtaining and maintaining good dental health."
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx(GridMixPic, {
          item: true,
          xs: 12,
          md: 6,
          children: /*#__PURE__*/jsx_runtime_.jsx("img", {
            src: "/images/homePage/mix.png",
            alt: ""
          })
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
        container: true,
        spacing: 2,
        children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
          item: true,
          xs: 12,
          md: 12,
          children: /*#__PURE__*/jsx_runtime_.jsx(BgBannerCenter, {
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
              sx: {
                paddingTop: '100px'
              },
              container: true,
              spacing: 2,
              children: [/*#__PURE__*/jsx_runtime_.jsx(GridAboutUsBanner, {
                item: true,
                md: 6,
                xs: 12,
                children: /*#__PURE__*/jsx_runtime_.jsx("img", {
                  src: "/images/homePage/aboutus-homepage-top.png",
                  alt: "pic"
                })
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
                sx: {
                  textAlign: 'left'
                },
                item: true,
                md: 6,
                xs: 12,
                children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                  sx: {
                    color: '#FFF',
                    fontWeight: '700'
                  },
                  variant: "h3",
                  gutterBottom: true,
                  component: "div",
                  children: "Achieve The Best Oral Health Possible With Our Team."
                }), /*#__PURE__*/jsx_runtime_.jsx(AbutusButton, {
                  sx: {
                    color: '#4060FF',
                    backgroundColor: '#fff',
                    minWidth: '160px',
                    minHeight: '45px',
                    fontWeight: '700'
                  },
                  children: 'about US'
                })]
              })]
            })
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(SloganRow, {
          item: true,
          xs: 12,
          md: 12,
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
            sx: {
              textAlign: 'center'
            },
            children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
              sx: {
                marginBottom: '-50px',
                color: '#DCDCDC',
                fontWeight: '900'
              },
              variant: "h1",
              gutterBottom: true,
              component: "div",
              children: "Benefits"
            }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
              sx: {
                color: '#476B8A',
                fontWeight: '700'
              },
              variant: "h3",
              gutterBottom: true,
              component: "div",
              children: "A&E"
            })]
          })
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
        container: true,
        spacing: 2,
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(GridIconContent, {
          item: true,
          xs: 12,
          md: 4,
          children: [/*#__PURE__*/jsx_runtime_.jsx("img", {
            src: "/images/icon/homePage/1.png",
            alt: ""
          }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
            sx: {
              color: '#476B8A',
              fontWeight: '700'
            },
            variant: "h5",
            gutterBottom: true,
            component: "div",
            children: "Healthier You"
          }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
            sx: {
              color: '#343434'
            },
            variant: "subtitle1",
            gutterBottom: true,
            component: "div",
            children: "We work with you to help keep your mouth healthy, attain and maintain oral health, which in turn makes an important contribution to your overall health."
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(GridIconContent, {
          item: true,
          xs: 12,
          md: 4,
          children: [/*#__PURE__*/jsx_runtime_.jsx("img", {
            src: "/images/icon/homePage/2.png",
            alt: ""
          }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
            sx: {
              color: '#476B8A',
              fontWeight: '700'
            },
            variant: "h5",
            gutterBottom: true,
            component: "div",
            children: "Affodable"
          }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
            sx: {
              color: '#343434'
            },
            variant: "subtitle1",
            gutterBottom: true,
            component: "div",
            children: "Not everyone has dental insurance. At A&E Dental Centre, you can expect to get professional, immaculate and personalized dental services at discounted rates."
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(GridIconContent, {
          item: true,
          xs: 12,
          md: 4,
          children: [/*#__PURE__*/jsx_runtime_.jsx("img", {
            src: "/images/icon/homePage/3.png",
            alt: ""
          }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
            sx: {
              color: '#476B8A',
              fontWeight: '700'
            },
            variant: "h5",
            gutterBottom: true,
            component: "div",
            children: "Convinient"
          }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
            sx: {
              color: '#343434'
            },
            variant: "subtitle1",
            gutterBottom: true,
            component: "div",
            children: "We appreciate your daily busy schedules. We offer a relaxed environment where you do not feel rushed and are scheduled in a time that works for you."
          })]
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx(SloganRow, {
        sx: {
          marginTop: '100px'
        },
        item: true,
        xs: 12,
        md: 12,
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
          sx: {
            textAlign: 'center'
          },
          children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
            sx: {
              marginBottom: '-50px',
              color: '#DCDCDC',
              fontWeight: '900'
            },
            variant: "h1",
            gutterBottom: true,
            component: "div",
            children: "Services"
          }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
            sx: {
              color: '#476B8A',
              fontWeight: '700'
            },
            variant: "h3",
            gutterBottom: true,
            component: "div",
            children: "We Will Give Many Reasons To Smile"
          })]
        })
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
        container: true,
        children: [/*#__PURE__*/jsx_runtime_.jsx(GridPics, {
          item: true,
          xs: 12,
          md: 4,
          children: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
            variant: "h4",
            gutterBottom: true,
            component: "div",
            children: "General Dentistry"
          })
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(GridPicTo, {
          item: true,
          xs: 12,
          md: 4,
          children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
            className: "firstContentPicTo",
            variant: "h4",
            gutterBottom: true,
            component: "div",
            children: "Dental Hygiene"
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
            className: "secendContentPicTo",
            children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              children: [/*#__PURE__*/jsx_runtime_.jsx((ArrowForwardIos_default()), {}), /*#__PURE__*/jsx_runtime_.jsx("p", {
                variant: "h5",
                gutterBottom: true,
                component: "div",
                children: "Dental Hygiene"
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              children: [/*#__PURE__*/jsx_runtime_.jsx((ArrowForwardIos_default()), {}), /*#__PURE__*/jsx_runtime_.jsx("p", {
                variant: "h5",
                gutterBottom: true,
                component: "div",
                children: "Dental Hygiene"
              })]
            })]
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx(GridPicT, {
          item: true,
          xs: 12,
          md: 4,
          children: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
            variant: "h4",
            gutterBottom: true,
            component: "div",
            children: "Cosmetic Dentistry"
          })
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
        sx: {
          marginTop: '100px'
        },
        container: true,
        spacing: 2,
        children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
          item: true,
          xs: 12,
          md: 4,
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Box, {
            children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
              sx: {
                color: '#476B8A',
                fontWeight: '700'
              },
              variant: "h4",
              gutterBottom: true,
              component: "div",
              children: "Our Happy Patients"
            }), /*#__PURE__*/jsx_runtime_.jsx(material_.Stack, {
              spacing: 1,
              children: /*#__PURE__*/jsx_runtime_.jsx(material_.Rating, {
                name: "half-rating",
                defaultValue: 2.5,
                precision: 0.5
              })
            }), /*#__PURE__*/jsx_runtime_.jsx(GoogleBox, {
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                href: "#",
                children: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                  variant: "h6",
                  gutterBottom: true,
                  component: "div",
                  children: "See More Google Reviews"
                })
              })
            })]
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
          item: true,
          xs: 12,
          md: 4,
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(BoxContentRevies, {
            children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
              sx: {
                color: '#343434'
              },
              variant: "body1",
              gutterBottom: true,
              component: "div",
              children: "A&E Dental Centre is a well-organized and clean office. They helped me out to re-schedule my appointments many times and treated me with respect. It feels like home here"
            }), /*#__PURE__*/jsx_runtime_.jsx("a", {
              href: "#",
              children: "Mohammad Hassan, Etobicoke"
            })]
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
          item: true,
          xs: 12,
          md: 4,
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(BoxContentRevies, {
            children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
              sx: {
                color: '#343434'
              },
              variant: "body1",
              gutterBottom: true,
              component: "div",
              children: "Although visits to the dentist are typically frightening, the friendly service makes it comfortable in here. A&E Dental Centre is my favourite dental office!"
            }), /*#__PURE__*/jsx_runtime_.jsx("a", {
              href: "#",
              children: "Shamsa Abdullahi, Etobicoke"
            })]
          })
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx(SloganRow, {
        container: true,
        spacing: 2,
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
          item: true,
          md: 12,
          xs: 12,
          lg: 12,
          sx: {
            textAlign: 'center',
            marginTop: '100px'
          },
          children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
            sx: {
              marginBottom: '-50px',
              color: '#DCDCDC',
              fontWeight: '900'
            },
            variant: "h1",
            gutterBottom: true,
            component: "div",
            children: "Contact"
          }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
            sx: {
              color: '#476B8A',
              fontWeight: '700'
            },
            variant: "h3",
            gutterBottom: true,
            component: "div",
            children: "Our Clinic Contact Information"
          })]
        })
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
        sx: {
          alignItems: 'center'
        },
        container: true,
        spacing: 2,
        children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
          item: true,
          md: 6,
          lg: 6,
          xs: 12,
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(FormGrid, {
            children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(LabelInput, {
              children: ["Full Name", /*#__PURE__*/jsx_runtime_.jsx(InputForm, {
                type: "text",
                name: "name"
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(LabelInput, {
              children: ["Email Address", /*#__PURE__*/jsx_runtime_.jsx(InputForm, {
                type: "mail",
                name: "Emaile"
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(LabelInput, {
              children: ["Phone Number", /*#__PURE__*/jsx_runtime_.jsx(InputForm, {
                type: "tel",
                name: "PhoneNumber"
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(LabelInput, {
              children: ["Message", /*#__PURE__*/jsx_runtime_.jsx(TextareaForm, {})]
            }), /*#__PURE__*/jsx_runtime_.jsx(ButtonDiv, {
              children: /*#__PURE__*/jsx_runtime_.jsx(SubmitInput, {
                type: "submit",
                value: "Submit"
              })
            })]
          })
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
          item: true,
          md: 6,
          lg: 6,
          xs: 12,
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
            children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
              sx: {
                marginBottom: '10px',
                fontWeight: '700',
                color: '#323232'
              },
              variant: "h6",
              gutterBottom: true,
              component: "div",
              children: "Hours"
            }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
              sx: {
                color: '#323232'
              },
              variant: "body2",
              gutterBottom: true,
              children: "Mon-Thur : 8am - 5pm"
            }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
              sx: {
                color: '#323232'
              },
              variant: "body2",
              gutterBottom: true,
              children: "Friday : 8am - 5pm"
            }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
              sx: {
                color: '#323232'
              },
              variant: "body2",
              gutterBottom: true,
              children: "Sat : With Appointment"
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
            children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
              sx: {
                marginBottom: '10px',
                marginTop: '10%',
                fontWeight: '700',
                color: '#323232'
              },
              variant: "h6",
              gutterBottom: true,
              component: "div",
              children: "Phone Number"
            }), /*#__PURE__*/jsx_runtime_.jsx(TypographyLink, {
              variant: "body2",
              gutterBottom: true,
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                href: "tel:+1416746005:",
                children: "(416) 746-0005"
              })
            }), /*#__PURE__*/jsx_runtime_.jsx(TypographyLink, {
              variant: "body2",
              gutterBottom: true,
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                href: "tel:+6476205444",
                children: "(647) 620-5444"
              })
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
            children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
              sx: {
                marginBottom: '10px',
                marginTop: '10%',
                fontWeight: '700',
                color: '#323232'
              },
              variant: "h6",
              gutterBottom: true,
              component: "div",
              children: "Address"
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Typography, {
              sx: {
                color: '#323232'
              },
              variant: "body2",
              gutterBottom: true,
              children: ["3212 Weston Road, North York,", /*#__PURE__*/jsx_runtime_.jsx("br", {}), "M9M 2T7 Ontario, Canada"]
            }), /*#__PURE__*/jsx_runtime_.jsx(TypographyLink, {
              variant: "body2",
              gutterBottom: true,
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                href: "#",
                children: "Get Direction"
              })
            })]
          })]
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
        container: true,
        children: /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
          item: true,
          xs: 12,
          children: /*#__PURE__*/jsx_runtime_.jsx("iframe", {
            title: "map",
            src: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d809.69758998853!2d51.415313829277395!3d35.73137399876139!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3f8e014eb0073efb%3A0x7d59079f25f6d85a!2sMammut!5e0!3m2!1sen!2s!4v1587801898468!5m2!1sen!2s",
            width: "100%",
            style: {
              marginBottom: '45px',
              marginTop: '100px',
              zIndex: '1'
            },
            height: "320px",
            frameborder: "0"
          })
        })
      })]
    })]
  });
};

const LabelInput = (styled_default()).label`
color:#323232

`;
const ButtonDiv = (styled_default()).div`
font-weight:700 ;
text-align:center ;
`;
const InputForm = (styled_default()).input`
width:100% ;
padding:10px ;
border: 1px solid #A6A6A6 ;
border-radius:5px ;
position:block ;
min-height:50px ;
margin: 6px 0 20px 0;
:focus { 
    outline: none !important;
    border-color: #6875F7;
    
}`;
const TextareaForm = (styled_default()).textarea`
  width:100% ;
border: 1px solid #A6A6A6 ;
border-radius:5px ;
position:block ;
min-height:112px ;
margin: 6px 0 20px 0;
padding:10px ;
:focus { 
    outline: none !important;
    border-color: #6875F7;
    
}
`;
const SubmitInput = (styled_default()).input`
font-family:Peyda  !important;
font-weight:700 ;
background: #6875F7;
border-radius: 5px;
height:45px ;
min-width:112px ;
border:none ;
color:#fff ;
text-align:center ;
cursor:pointer;
:hover{
  background: #4F5FFF;
border-radius: 5px;

}`;
const TypographyLink = styled_default()(material_.Typography)`
  a {
    color: #6875f7;
  }
`;
const RubikTiitle = styled_default()(material_.Typography)`
  font-weight: 900;
`;
const FormGrid = (styled_default()).form`
  background: #ffffff;
  box-shadow: 0px 0px 17px rgba(155, 155, 155, 0.25);
  border-radius: 5px;
  padding: 25px;
`;
const AbutusButton = styled_default()(Button/* default */.Z)`
:hover{
color:#fff ;
background-color:#4F5FFF;
}
`;
const SloganRow = styled_default()(material_.Grid)`
  margin-bottom: 50px;
`;
const ContainerCom = (/* unused pure expression or super */ null && (styled(Container)`
  box-shadow: 0px 0px 16px rgb(197 197 197 / 25%);
  border-radius: 52px;
  width: 80%;
  background-color: #fff;
  border: 1px solid #817e84;
  min-height: 272px;
`));
const ImgServises = (/* unused pure expression or super */ null && (styled(Grid)`
  background-image: url('/images/homePage/Servises1.png');
  background-size: cover;
  height: 450px;
  display: flex;
  flex-direction: column;
  align-content: flex-start;
  justify-content: flex-start;
  align-items: flex-start;
  color: #fff;
  background-color: #000;
  border-radius: 25px;
  font-size: 1.5rem;
  line-height: 2.5;
`));
const ImgServisesR = (/* unused pure expression or super */ null && (styled(Grid)`
  background-image: url('/images/homePage/Servises1.png');
  background-size: cover;
  height: 450px;
  display: flex;
  flex-direction: column;
  align-content: flex-end;
  justify-content: flex-end;
  align-items: flex-end;
  color: #fff;
  background-color: #000;
  border-radius: 25px;
  font-size: 1.5rem;
  line-height: 2.5;
`));
const BgBannerCenter = styled_default()(material_.Box)`
  background-image: url('/images/homePage/BgBannerCenter.png');
  background-size: cover;
  height: 406px;
  text-align: center;
  margin-bottom: 20%;
  border-radius:5px ;
`;
const GridPics = styled_default()(material_.Grid)`
  background-image: url('/images/homePage/p1.png');
  background-size: cover;
  height: 425px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  border-top-left-radius: 5px;
  border-bottom-left-radius: 5px;
`;
const GridPicTo = styled_default()(material_.Grid)`
  background-image: url('/images/homePage/p2.png');
  background-size: cover;
  height: 425px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  transition: all 0.5s ease;
    .secendContentPicTo{
    display:none ;
  }
  
  .firstContentPicTo{
    display:block ;
  }
  :hover{
    .firstContentPicTo{
    display:none ;
  }
  .secendContentPicTo{
    display: flex;
    flex-direction: column;
    div{
      display: flex;
    align-items: center;
    justify-content: space-around;
    width: 120%;

    }
  }
  }
`;
const GridPicT = styled_default()(material_.Grid)`
  background-image: url('/images/homePage/p3.png');
  background-size: cover;
  height: 425px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  border-top-right-radius: 5px;
  border-bottom-right-radius: 5px;
`;
const TypogerapyOnBanner = (/* unused pure expression or super */ null && (styled(Typography)`
  color: #fff;
  justify-content: center;
  display: flex;
  align-items: center;
  padding-top: 10%;
`));
const GoogleBox = styled_default()(material_.Typography)`
  margin-bottom: 50px;
  margin-top: 30px;
  border-bottom: 1px solid #323232;
  width: fit-content;
`;
const BoxContentRevies = styled_default()(material_.Box)`
 background: #ffffff;
    box-shadow: 0px 0px 30px rgb(181 181 181 / 25%);
    border-radius: 5px;
    min-height: 218px;
    padding: 30px;
    display: flex;
    align-items: flex-start;
    flex-direction: column;
    align-content: flex-start;
    justify-content: space-between;
   
  a {
    color: #4060ff;
    font-weight:700 ;
  }
`;
const GridMixPic = styled_default()(material_.Grid)`
  z-index: 1;
  img {
    width: 100%;
  }
`;
const GridIconContent = styled_default()(material_.Grid)`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-align: center;
  img {
    margin-bottom: 15px;
  }
`;
const GridAboutUsBanner = styled_default()(material_.Grid)`

  img {
    width: 90%;
  }
`;
const getStaticProps = async ({
  locale
}) => {
  return {
    props: _objectSpread({
      locale
    }, await (0,serverSideTranslations_.serverSideTranslations)(locale, ['common'], (i18n_default())))
  };
};
/* harmony default export */ const pages = (Home);

/***/ }),

/***/ 1480:
/***/ ((module) => {

module.exports = require("@emotion/styled");

/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 3819:
/***/ ((module) => {

module.exports = require("@mui/material/Button");

/***/ }),

/***/ 4475:
/***/ ((module) => {

module.exports = require("@mui/material/Container");

/***/ }),

/***/ 1635:
/***/ ((module) => {

module.exports = require("dayjs");

/***/ }),

/***/ 2764:
/***/ ((module) => {

module.exports = require("jalali-dayjs");

/***/ }),

/***/ 1377:
/***/ ((module) => {

module.exports = require("next-i18next");

/***/ }),

/***/ 5460:
/***/ ((module) => {

module.exports = require("next-i18next/serverSideTranslations");

/***/ }),

/***/ 8028:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3018:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 4417:
/***/ ((module) => {

module.exports = require("react-spring");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [639,675,558,126,219,103], () => (__webpack_exec__(9376)));
module.exports = __webpack_exports__;

})();