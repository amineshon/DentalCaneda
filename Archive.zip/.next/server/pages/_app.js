"use strict";
(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 708:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(1377);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
;// CONCATENATED MODULE: external "react-redux"
const external_react_redux_namespaceObject = require("react-redux");
;// CONCATENATED MODULE: external "redux-persist/lib/integration/react"
const react_namespaceObject = require("redux-persist/lib/integration/react");
;// CONCATENATED MODULE: external "@reduxjs/toolkit"
const toolkit_namespaceObject = require("@reduxjs/toolkit");
;// CONCATENATED MODULE: external "redux-persist"
const external_redux_persist_namespaceObject = require("redux-persist");
;// CONCATENATED MODULE: external "redux-persist/lib/storage"
const storage_namespaceObject = require("redux-persist/lib/storage");
var storage_default = /*#__PURE__*/__webpack_require__.n(storage_namespaceObject);
;// CONCATENATED MODULE: external "redux"
const external_redux_namespaceObject = require("redux");
;// CONCATENATED MODULE: ./src/redux/slices/app/slice.ts
/* eslint-disable no-param-reassign */

const initialState = {
  loading: false,
  theme: 'light'
};
const appSlice = (0,toolkit_namespaceObject.createSlice)({
  name: 'app',
  initialState,
  reducers: {
    toggleLoading: state => {
      state.loading = !state.loading;
    },
    toggleTheme: state => {
      state.theme = state.theme === 'light' ? 'dark' : 'light';
    },
    setTheme: (state, action) => {
      const theme = action.payload;
      state.theme = theme;
    }
  }
});
/* harmony default export */ const slice = (appSlice);
;// CONCATENATED MODULE: ./src/redux/slices/auth/slice.ts
/* eslint-disable no-param-reassign */

const slice_initialState = {
  accessToken: '',
  refreshToken: '',
  loggedIn: false
};
const authSlice = (0,toolkit_namespaceObject.createSlice)({
  name: 'auth',
  initialState: slice_initialState,
  reducers: {
    login: (state, action) => {
      const {
        accessToken,
        refreshToken
      } = action.payload;
      state.accessToken = accessToken;
      state.refreshToken = refreshToken;
      state.loggedIn = true;
    },
    logout: () => slice_initialState
  }
});
/* harmony default export */ const auth_slice = (authSlice);
;// CONCATENATED MODULE: ./src/redux/slices/user/slice.ts
/* eslint-disable no-param-reassign */

const user_slice_initialState = {
  profile: {
    mobile: '',
    name: ''
  }
};
const userSlice = (0,toolkit_namespaceObject.createSlice)({
  name: 'user',
  initialState: user_slice_initialState,
  reducers: {
    updateProfile: (state, action) => {
      const {
        payload
      } = action;
      state.profile = payload;
    },
    clearProfile: () => user_slice_initialState
  }
});
/* harmony default export */ const user_slice = (userSlice);
;// CONCATENATED MODULE: ./src/redux/slices/index.ts



;// CONCATENATED MODULE: ./src/redux/reducers.ts




const rootPersistConfig = {
  key: 'root',
  blacklist: ['basket'],
  version: 1,
  storage: (storage_default())
};
const rootReducer = (0,external_redux_namespaceObject.combineReducers)({
  app: slice.reducer,
  user: user_slice.reducer,
  auth: auth_slice.reducer
});
/* harmony default export */ const reducers = ((0,external_redux_persist_namespaceObject.persistReducer)(rootPersistConfig, rootReducer));
;// CONCATENATED MODULE: ./src/redux/store.ts




const store = (0,toolkit_namespaceObject.configureStore)({
  reducer: reducers,
  middleware: getDefaultMiddleware => getDefaultMiddleware({
    serializableCheck: {
      ignoredActions: [external_redux_persist_namespaceObject.FLUSH, external_redux_persist_namespaceObject.REHYDRATE, external_redux_persist_namespaceObject.PAUSE, external_redux_persist_namespaceObject.PERSIST, external_redux_persist_namespaceObject.PURGE, external_redux_persist_namespaceObject.REGISTER]
    }
  }).prepend(),
  devTools: false
});
const persistor = (0,external_redux_persist_namespaceObject.persistStore)(store);
const useAppDispatch = () => (0,external_react_redux_namespaceObject.useDispatch)();
;// CONCATENATED MODULE: ./src/enhancers/wrappers/ConditionalWrapper.tsx
const ConditionalWrapper = ({
  condition,
  wrapper,
  children
}) => condition ? wrapper(children) : children; // Export default


/* harmony default export */ const wrappers_ConditionalWrapper = (ConditionalWrapper);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./src/enhancers/wrappers/withRedux.tsx


 // Libs





const PersistWrapper = c => /*#__PURE__*/jsx_runtime_.jsx(react_namespaceObject.PersistGate, {
  loading: null,
  persistor: persistor,
  children: c
});
/* withRedux Component =================== */


const WithRedux = ({
  children
}) => /*#__PURE__*/jsx_runtime_.jsx(external_react_redux_namespaceObject.Provider, {
  store: store,
  children: /*#__PURE__*/jsx_runtime_.jsx(wrappers_ConditionalWrapper, {
    condition: false,
    wrapper: PersistWrapper,
    children: children
  })
}); // Export default


/* harmony default export */ const withRedux = (WithRedux);
;// CONCATENATED MODULE: external "next-seo"
const external_next_seo_namespaceObject = require("next-seo");
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: ./src/configs/api.ts
/* eslint-disable key-spacing */
const api = {
  // -------------- Authentication ----------
  auth: {
    endpoint: '/auth',
    method: 'POST',
    escapeAuthToken: true
  },
  authVerify: {
    endpoint: '/auth/verification',
    method: 'POST',
    escapeAuthToken: true
  },
  getProfile: {
    endpoint: '/profile',
    method: 'GET'
  },
  // -------------- Product -----------------
  getProducts: {
    endpoint: '/products',
    method: 'GET',
    escapeAuthToken: true
  },
  getCategories: {
    endpoint: '/categories',
    method: 'GET',
    escapeAuthToken: true
  },
  // -------------- Order -------------------
  createOrder: {
    endpoint: '/order',
    method: 'POST'
  },
  getOrder: {
    endpoint: '/order/{id}',
    method: 'POST'
  }
};
/* harmony default export */ const configs_api = ((/* unused pure expression or super */ null && (api)));
;// CONCATENATED MODULE: ./src/configs/app.ts
const app = {
  debounce_delay: 1000,
  // milliseconds
  verification_opt_renew: 56,
  // seconds
  // populate from envs
  website_base_url: "https://bitmax.com",
  api_base_url: "https://api.bitmax.com",
  sentry_url: "",
  google_analytics_key: "",
  google_auth_client_id: "",
  google_recaptcha_sitekey: "provide a sitekey"
};
/* harmony default export */ const configs_app = ((/* unused pure expression or super */ null && (app)));
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
;// CONCATENATED MODULE: ./src/theme/palette/common.ts
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const common = {
  primary: {
    main: '#005CB3',
    contrastText: 'white'
  },
  secondary: {
    main: '#2D2E83',
    contrastText: 'white'
  },
  error: {
    main: '#f46a6a',
    contrastText: 'white',
    dark: material_.colors.red[900],
    light: material_.colors.red[400]
  },
  warning: {
    main: '#FCB400',
    contrastText: 'white',
    dark: material_.colors.yellow[900],
    light: material_.colors.yellow[400]
  },
  success: {
    main: '#34c38f',
    contrastText: 'white',
    dark: material_.colors.green[900],
    light: material_.colors.green[400]
  },
  info: {
    main: '#0B8EE6',
    contrastText: 'white',
    dark: material_.colors.green[900],
    light: material_.colors.green[400]
  },
  grey: _objectSpread({
    main: material_.colors.grey[700]
  }, material_.colors.grey)
};
/* harmony default export */ const palette_common = (common);
;// CONCATENATED MODULE: ./src/theme/palette/light.ts


const light = {
  text: {
    primary: '#161616',
    secondary: palette_common.primary.main,
    alternate: material_.colors.grey[100],
    hint: material_.colors.grey[600],
    link: material_.colors.blue[600],
    tag: '#192434'
  },
  background: {
    default: '#F6F7F9',
    paper: 'white',
    toolbar: '#ffffff',
    tableHeader: 'rgb(241, 243, 246)',
    card: '#ffff',
    dropDownMenu: '#FFFFFF',
    input: 'rgba(91, 102, 118, 0.1)',
    contactBox: '#F6F7F9',
    faqMenuBar: '#FFF',
    faq: '#F6F7F9'
  },
  divider: material_.colors.grey[200],
  border: {
    default: '#E7E8F8',
    primary: 'rgba(26, 56, 96, 0.1)'
  },
  svg: {
    default: '#192434'
  },
  tag: {
    default: 'rgba(91, 102, 118, 0.1)'
  },
  designColor: {
    defaultLogoType: '#fcb400',
    textDefult: '#263140',
    faqBg: '#f3f5f7',
    faqContent: '#192434',
    button: '#fcb400'
  },
  card: {
    hiringCard: '#fff'
  },
  transparentContent: {
    termsConditions: '-webkit-linear-gradient(#333, #eee)'
  },
  number: '#F52419'
};
/* harmony default export */ const palette_light = (light);
;// CONCATENATED MODULE: ./src/theme/palette/dark.ts


const dark = {
  text: {
    primary: material_.colors.grey[200],
    secondary: palette_common.primary.main,
    alternate: material_.colors.grey[900],
    hint: material_.colors.grey[400],
    link: material_.colors.blue[600],
    tag: '#EBF4FF'
  },
  background: {
    default: '#223348',
    paper: '#2B3D54',
    toolbar: '#20232a',
    tableHeader: '#20232a',
    card: 'linear-gradient(111.29deg, #D3D3D3 0%, rgba(211, 211, 211, 0) 65.87%)',
    dropDownMenu: '#3A4E66',
    input: '#3A4E66',
    contactBox: '#3A4E66',
    faqMenuBar: '#3A4E66',
    faq: '#2D3D51'
  },
  divider: material_.colors.grey[800],
  border: {
    default: material_.colors.grey[800],
    primary: '#F5F9FF'
  },
  svg: {
    default: '#EBF4FF'
  },
  tag: {
    default: 'rgba(235, 244, 255, 0.2)'
  },
  card: {
    hiringCard: '#2C3D53'
  },
  transparentContent: {
    termsConditions: '-webkit-linear-gradient(#eee, #333)'
  },
  designColor: {
    defaultLogoType: '#fcb400',
    textDefault: '#DFE8F4',
    faqBg: '#2B3D54',
    faqContent: '#EDF0F4',
    button: '#fcb400'
  },
  number: '#FF5F57'
};
/* harmony default export */ const palette_dark = (dark);
;// CONCATENATED MODULE: ./src/theme/palette/index.ts



/* harmony default export */ const palette = ({
  common: palette_common,
  light: palette_light,
  dark: palette_dark
});
;// CONCATENATED MODULE: ./src/configs/seo.ts

const seo = {
  additionalMetaTags: [{
    name: 'viewport',
    content: 'width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0'
  }, {
    name: 'apple-mobile-web-app-status-bar-style',
    content: 'black'
  }, {
    name: 'theme-color',
    content: palette.common.primary.main
  }],
  openGraph: {
    type: 'website',
    locale: 'fa_IR'
  },
  twitter: {
    site: '',
    creator: '',
    cardType: ''
  }
};
/* harmony default export */ const configs_seo = (seo);
;// CONCATENATED MODULE: ./src/configs/route.ts
/* eslint-disable quote-props */

/* eslint-disable key-spacing */
const setting = {
  auth: false,
  private: false,
  layout: 'default',
  header: {
    visible: true,
    theme: 'default',
    fixedOnScroll: -1
  },
  footer: {
    visible: true
  },
  tabbar: {
    visible: true
  }
};
const route = {
  // Authentication related routes
  'auth-login': {
    href: '/login',
    layout: 'auth',
    auth: true
  },
  'auth-register': {
    href: '/register',
    layout: 'auth',
    auth: true
  },
  'auth-forget-password': {
    href: '/register',
    layout: 'auth',
    auth: true
  },
  // Dashboard related routes
  'dashboard': {
    href: '/app',
    layout: 'dashboard',
    private: true
  },
  'dashboard-ticket-list': {
    href: '/app/ticket/list',
    layout: 'dashboard',
    private: true
  },
  'dashboard-ticket-new': {
    href: '/app/ticket/new',
    layout: 'dashboard',
    private: true
  },
  'dashboard-ticket-view': {
    href: '/app/ticket/view/[id]',
    layout: 'dashboard',
    private: true
  },
  'dashboard-profile': {
    href: '/app/profile',
    layout: 'dashboard',
    private: true
  },
  'dashboard-cards': {
    href: '/app/cards',
    layout: 'dashboard',
    private: true
  },
  'dashboard-withdraw': {
    href: '/app/withdraw',
    layout: 'dashboard',
    private: true
  },
  'dashboard-deposit': {
    href: '/app/deposit',
    layout: 'dashboard',
    private: true
  },
  'dashboard-history': {
    href: '/app/history',
    layout: 'dashboard',
    private: true
  },
  'dashboard-security': {
    href: '/app/security',
    layout: 'dashboard',
    private: true
  },
  'dashboard-security-history': {
    href: '/app/security/history',
    layout: 'dashboard',
    private: true
  },
  'dashboard-wallet': {
    href: '/app/wallet',
    layout: 'dashboard',
    private: true
  },
  'dashboard-quick-order': {
    href: '/app/quick-order',
    layout: 'dashboard',
    private: true
  },
  'dashboard-referral': {
    href: '/app/referral',
    layout: 'dashboard',
    private: true
  },
  // Static routes
  'terms': {
    href: '/terms',
    layout: 'default',
    private: false
  },
  'contact': {
    href: '/contact',
    layout: 'default',
    private: false
  },
  'about': {
    href: '/about',
    layout: 'default',
    private: false
  },
  'product': {
    href: '/product/[id]',
    layout: 'default',
    private: false
  }
};
;// CONCATENATED MODULE: ./src/configs/index.ts




;// CONCATENATED MODULE: external "@mui/material/useMediaQuery"
const useMediaQuery_namespaceObject = require("@mui/material/useMediaQuery");
var useMediaQuery_default = /*#__PURE__*/__webpack_require__.n(useMediaQuery_namespaceObject);
// EXTERNAL MODULE: external "@emotion/styled"
var styled_ = __webpack_require__(1480);
var styled_default = /*#__PURE__*/__webpack_require__.n(styled_);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
;// CONCATENATED MODULE: ./src/components/Basic/Logo/index.tsx




const SVG = (styled_default()).svg`
  cursor: pointer;
`; // Components

const Logo = margin => {
  return /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
    href: "/",
    children: /*#__PURE__*/jsx_runtime_.jsx(LogoImg, {
      style: {
        cursor: 'pointer'
      },
      src: '/images/logo/DLogo.png',
      alt: "Logo",
      margin: margin
    })
  });
};

const LogoImg = (styled_default()).img`
  width: auto;
  margin: 0 ${props => props.margin ? props.margin.margin : '0'};
`;
/* harmony default export */ const Basic_Logo = (Logo);
// EXTERNAL MODULE: ./src/components/Basic/Button/index.tsx + 2 modules
var Basic_Button = __webpack_require__(9126);
;// CONCATENATED MODULE: ./src/layout/Header/index.tsx




 // Constants
// import ROUTE_CONSTANTS from 'constants/route';
// Components








const Header = () => {
  const profile = (0,external_react_redux_namespaceObject.useSelector)(state => state.user.profile);
  const loggedIn = (0,external_react_redux_namespaceObject.useSelector)(state => state.auth.loggedIn);
  const {
    t
  } = (0,external_next_i18next_.useTranslation)();
  const matches = useMediaQuery_default()(theme => theme.breakpoints.up('lg'), {
    noSsr: true
  });
  const router = (0,router_.useRouter)();
  const {
    locale,
    query,
    asPath,
    pathname
  } = router; /////////////////////////////////

  const [anchorElNav, setAnchorElNav] = external_react_default().useState(null);
  const [anchorLeftNav, setAnchorLeftNav] = external_react_default().useState(null);

  const handleOpenNavMenu = event => {
    setAnchorElNav(event.currentTarget);
  };

  const handleOpenNavLeftMenu = event => {
    setAnchorLeftNav(event.currentTarget);
  };

  const handleCloseNavMenu = () => {
    setAnchorElNav(null);
  };

  const handleCloseNavLeftMenu = () => {
    setAnchorLeftNav(null);
  }; //////////////////////////////////


  const links = [{
    key: '0',
    label: t('header.crypto-camp'),
    children: [{
      labels: t('header.quick_buy_sell'),
      details: t('header.quick_buy_sell_subtitle'),
      href: '/'
    }]
  }, {
    key: '1',
    label: t('header.crypto-market'),
    children: [{
      labels: t('header.cryptocurrency'),
      details: t('header.cryptocurrency_subtitle'),
      href: '/market'
    }]
  }, {
    key: '2',
    label: t('header.academy'),
    children: [{
      labels: t('header.blog'),
      details: t('header.blog_subtitle'),
      href: '/'
    }]
  }, {
    key: '3',
    label: t('header.about_us'),
    children: [{
      labels: t('header.about_us'),
      details: t('header.about_us_subtitle'),
      href: '/aboutUs'
    }, {
      labels: t('header.contact_us'),
      details: t('header.contact_us_subtitle'),
      href: '/contactUs'
    }, {
      labels: t('header.faq'),
      details: t('header.faq_subtitle'),
      href: '/faq'
    }]
  }];
  const mobileLinks = [{
    key: '0',
    label: t('header.crypto-camp'),
    children: [{
      labels: t('header.quick_buy_sell'),
      details: t('header.quick_buy_sell_subtitle'),
      href: '/'
    }]
  }, {
    key: '1',
    label: t('footer.support'),
    children: [{
      labels: t('header.faq'),
      href: '/faq'
    }, {
      labels: t('footer.registration_guide'),
      href: '/kycInfo'
    }]
  }, {
    key: '2',
    label: t('footer.terms_and_condition'),
    children: [{
      labels: t('footer.trading_rules'),
      href: '/termsandconditions'
    }, {
      labels: t('footer.trading_fee'),
      href: '/tradingRules'
    }]
  }];
  const MenuStyle = styled_default()(material_.Menu)`
    .MuiMenu-list,
    .MuiMenu-paper,
    .MuiMenu-root {
      width: 256px;
    }
  `;
  return /*#__PURE__*/jsx_runtime_.jsx(material_.AppBar, {
    color: "inherit",
    position: "fixed",
    sx: {
      background: 'transparent',
      left: '1px'
    },
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Box, {
      sx: {
        height: theme => theme.shape.headerHeight,
        display: 'flex',
        alignItems: 'center',
        maxWidth: '100%',
        padding: '57px 20px',
        background: {
          md: '#27272770',
          xs: 'linear-gradient(180deg, #120024 21.29%, #102441 142.94%)'
        }
      },
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(HeaderWeb, {
        sx: {
          display: {
            md: 'flex',
            xs: 'none'
          },
          alignItems: 'center',
          height: '100%',
          width: '100%'
        },
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          children: /*#__PURE__*/jsx_runtime_.jsx(Basic_Logo, {
            margin: '60px'
          })
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(Content, {
          children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
            sx: {
              flexGrow: 1
            }
          }), /*#__PURE__*/jsx_runtime_.jsx("a", {
            href: "./",
            children: "Home"
          }), /*#__PURE__*/jsx_runtime_.jsx("a", {
            href: "./hygiene",
            children: "Servises"
          }), /*#__PURE__*/jsx_runtime_.jsx("a", {
            href: "#",
            children: "About Us"
          }), /*#__PURE__*/jsx_runtime_.jsx(Basic_Button/* default */.Z, {
            children: 'Contact Us'
          })]
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
        sx: {
          flexGrow: 1,
          display: {
            xs: 'flex',
            md: 'none'
          },
          justifyContent: {
            xs: 'center'
          }
        },
        children: /*#__PURE__*/jsx_runtime_.jsx(Basic_Logo, {})
      })]
    })
  });
};

const HeaderWeb = styled_default()(material_.Box)`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px;
  div {
    justify-content: center;
    align-items: center;
    display: flex;
  }
`;
const Content = (styled_default()).div`
  a {
    margin: 0 15px;
    color: #fff;
    transition: all 0.5s ease;
  }
  a:hover {
    border-bottom: 3px solid #fff;
    border-radius: 2%;
  }
`;
const ButtonHeadr = (/* unused pure expression or super */ null && (styled(Button)`
  :hover {
    border-bottom: none !important;
    border-radius: none !important;
  }
`));
/* harmony default export */ const layout_Header = (Header);
;// CONCATENATED MODULE: external "@mui/material/Typography"
const Typography_namespaceObject = require("@mui/material/Typography");
var Typography_default = /*#__PURE__*/__webpack_require__.n(Typography_namespaceObject);
;// CONCATENATED MODULE: external "@mui/icons-material/Home"
const Home_namespaceObject = require("@mui/icons-material/Home");
var Home_default = /*#__PURE__*/__webpack_require__.n(Home_namespaceObject);
;// CONCATENATED MODULE: external "@mui/material/Grid"
const Grid_namespaceObject = require("@mui/material/Grid");
var Grid_default = /*#__PURE__*/__webpack_require__.n(Grid_namespaceObject);
;// CONCATENATED MODULE: ./src/layout/Footer/index.tsx












// Component
const Footer = () => {
  const matches = useMediaQuery_default()(theme => theme.breakpoints.up('md'), {
    noSsr: true
  });
  const route = (0,router_.useRouter)();
  const {
    pathname
  } = route;
  const {
    t
  } = (0,external_next_i18next_.useTranslation)();
  const [value, setValue] = external_react_default().useState(pathname);

  const handleChange = (event, newValue) => {
    setValue(newValue);
    route.push(`${newValue}`);
  };

  const BottomNavigationActionStyled = styled_default()(material_.BottomNavigationAction)`
    .Mui-selected {
      color: ${p => p.theme.palette.warning.main};
    }
  `;
  const BottomNavigationStyled = styled_default()(material_.BottomNavigation)`
    .MuiBottomNavigationAction-root {
      color: ${p => p.theme.palette.text.primary};
      flex-direction: row;
    }

    .Mui-selected {
      color: ${p => p.theme.palette.warning.main} !important;
    }
  `;
  return matches ? /*#__PURE__*/jsx_runtime_.jsx(FooterDiv, {
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)((Grid_default()), {
      container: true,
      spacing: 2,
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(GridFooter, {
        item: true,
        xs: 3,
        children: [/*#__PURE__*/jsx_runtime_.jsx((Typography_default()), {
          sx: {
            fontWeight: '700'
          },
          variant: "h5",
          gutterBottom: true,
          component: "div",
          children: "Services"
        }), /*#__PURE__*/jsx_runtime_.jsx("a", {
          href: "./hygiene",
          children: /*#__PURE__*/jsx_runtime_.jsx((Typography_default()), {
            variant: "body1",
            gutterBottom: true,
            component: "div",
            children: "Dental Hygiene"
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("a", {
          href: "./general",
          children: /*#__PURE__*/jsx_runtime_.jsx((Typography_default()), {
            variant: "body1",
            gutterBottom: true,
            component: "div",
            children: "General Dentistry"
          })
        }), /*#__PURE__*/jsx_runtime_.jsx((Typography_default()), {
          variant: "body1",
          gutterBottom: true,
          component: "div",
          children: "Cosmetic Dentistry"
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(GridFooter, {
        item: true,
        xs: 3,
        children: [/*#__PURE__*/jsx_runtime_.jsx((Typography_default()), {
          sx: {
            fontWeight: '700'
          },
          variant: "h5",
          gutterBottom: true,
          component: "div",
          children: "Phone Number"
        }), /*#__PURE__*/jsx_runtime_.jsx((Typography_default()), {
          variant: "body1",
          gutterBottom: true,
          component: "div",
          children: /*#__PURE__*/jsx_runtime_.jsx("a", {
            href: "tel:+1416746005",
            children: "(416) 746-0005"
          })
        }), /*#__PURE__*/jsx_runtime_.jsx((Typography_default()), {
          variant: "body1",
          gutterBottom: true,
          component: "div",
          children: /*#__PURE__*/jsx_runtime_.jsx("a", {
            href: "tel:+6476205444",
            children: "(647) 620-5444"
          })
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(GridFooter, {
        item: true,
        xs: 3,
        children: [/*#__PURE__*/jsx_runtime_.jsx((Typography_default()), {
          sx: {
            fontWeight: '700'
          },
          variant: "h5",
          gutterBottom: true,
          component: "div",
          children: "Hours"
        }), /*#__PURE__*/jsx_runtime_.jsx((Typography_default()), {
          variant: "body1",
          gutterBottom: true,
          component: "div",
          children: "Mon-Thur : 8am - 5pm"
        }), /*#__PURE__*/jsx_runtime_.jsx((Typography_default()), {
          variant: "body1",
          gutterBottom: true,
          component: "div",
          children: "Friday : 8am - 5pm"
        }), /*#__PURE__*/jsx_runtime_.jsx((Typography_default()), {
          variant: "body1",
          gutterBottom: true,
          component: "div",
          children: "Sat : With Appointment"
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(GridFooter, {
        item: true,
        xs: 3,
        children: [/*#__PURE__*/jsx_runtime_.jsx((Typography_default()), {
          sx: {
            fontWeight: '700'
          },
          variant: "h5",
          gutterBottom: true,
          component: "div",
          children: "Address"
        }), /*#__PURE__*/jsx_runtime_.jsx((Typography_default()), {
          variant: "body1",
          gutterBottom: true,
          component: "div",
          children: "3212 Weston Road, North York, M9M 2T7 Ontario, Canada"
        })]
      })]
    })
  }) :
  /*#__PURE__*/
  // responsive footer
  (0,jsx_runtime_.jsxs)(BottomNavigationStyled, {
    sx: {
      width: '100%',
      position: 'fixed',
      bottom: 0,
      zIndex: 10
    },
    value: value,
    onChange: handleChange,
    children: [/*#__PURE__*/jsx_runtime_.jsx(BottomNavigationActionStyled, {
      label: "Home",
      value: "/",
      icon: /*#__PURE__*/jsx_runtime_.jsx((Home_default()), {})
    }), /*#__PURE__*/jsx_runtime_.jsx(BottomNavigationActionStyled, {
      label: "Servises",
      value: "/",
      icon: /*#__PURE__*/jsx_runtime_.jsx((Home_default()), {})
    }), /*#__PURE__*/jsx_runtime_.jsx(BottomNavigationActionStyled, {
      label: "Blog",
      value: "/",
      icon: /*#__PURE__*/jsx_runtime_.jsx((Home_default()), {})
    }), /*#__PURE__*/jsx_runtime_.jsx(BottomNavigationActionStyled, {
      label: "Contact Us",
      value: "/",
      icon: /*#__PURE__*/jsx_runtime_.jsx((Home_default()), {})
    })]
  });
};

const GridFooter = styled_default()((Grid_default()))`
  color: #fff;
`;
const FooterDiv = (styled_default()).div`
  background: #476b8a;
  display: flex;
  min-height: 315px;
  align-items: center;
  padding: 0 50px;
`;
const TypographyLink = (/* unused pure expression or super */ null && (styled(Typography)`
  a {
    color: #6875f7;
  }
`));
const FooterLinkRow = (styled_default()).div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-direction: row;
  margin-bottom: 30px;
  padding-top: 40px;
`;
const FooterLine = (styled_default()).div`
  display: flex;
  color: #fff;
  justify-content: left;
  align-items: baseline;
  flex-direction: column;
  text-align: left;
  margin-top: 70px;
  line-height: 2;
`;
const Copyright = (styled_default()).p`
  color: #fcb400;
  font-size: 16px;
  text-align: center;
  margin-top: 100px;
`;
const Footer_LogoImg = (styled_default()).img`
  width: 190px;
`;
const LinkSection = (styled_default()).div`
  display: flex;
  align-items: flex-start;
  flex-direction: row;
  align-content: center;
  justify-content: space-between;
`;
const FooterGrid = (/* unused pure expression or super */ null && (styled(Grid)`
  display: flex;
  align-items: center;
`));
const LogoSection = (styled_default()).div`
  text-align: center;
`;
/* harmony default export */ const layout_Footer = (Footer);
;// CONCATENATED MODULE: ./src/layout/PageWrapper/style.ts
 // Styles

const Root = (styled_default()).div`
  min-height: 100vh;
  box-sizing: border-box;
  overflow-x: hidden;
  margin: 0;
  min-width: 0;
  display: flex;
  flex-direction: column;

  ${p => p.headerPadding && `
		
	`}

  .MuiInputLabel-root {
    /* @noflip */
    /* left: 0; */

    /* @noflip */
    /* right: auto; */
  }
`;
const style_Content = (styled_default()).div`
  padding-top: 24px;
  background-color: ${p => p.theme.palette.background.default};
  ${p => p.headerVisible && `
		min-height: calc(100vh - ${p.theme.shape.headerHeight}px);
	`}
`;
;// CONCATENATED MODULE: ./src/layout/PageWrapper/index.tsx
function PageWrapper_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function PageWrapper_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { PageWrapper_ownKeys(Object(source), true).forEach(function (key) { PageWrapper_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { PageWrapper_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function PageWrapper_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




 // libs and consts

 // styles







const PageWrapper = ({
  children
}) => {
  var _routeObject$routeCon, _routeObject$routeCon2;

  // const { query } = useRouter();
  const {
    t
  } = (0,external_next_i18next_.useTranslation)();
  const router = (0,router_.useRouter)();
  const routeObject = (0,external_react_.useMemo)(() => {
    const routeKey = Object.keys(route).find(r => {
      var _routeConfig$r;

      return ((_routeConfig$r = route[r]) === null || _routeConfig$r === void 0 ? void 0 : _routeConfig$r.href) === router.route;
    });
    return {
      routeKey,
      routeConfig: route[routeKey]
    };
  }, [router]);

  const settings = PageWrapper_objectSpread(PageWrapper_objectSpread({}, setting), routeObject === null || routeObject === void 0 ? void 0 : routeObject.routeConfig);

  settings.header = PageWrapper_objectSpread(PageWrapper_objectSpread({}, setting.header), routeObject === null || routeObject === void 0 ? void 0 : (_routeObject$routeCon = routeObject.routeConfig) === null || _routeObject$routeCon === void 0 ? void 0 : _routeObject$routeCon.header);
  settings.footer = PageWrapper_objectSpread(PageWrapper_objectSpread({}, setting.footer), routeObject === null || routeObject === void 0 ? void 0 : (_routeObject$routeCon2 = routeObject.routeConfig) === null || _routeObject$routeCon2 === void 0 ? void 0 : _routeObject$routeCon2.footer);
  const headerVisible = settings.header.visible;
  const pageTitle = routeObject.routeKey ? `${t(`title.${routeObject.routeKey}`)}` : '';
  const finalTitle = `${pageTitle} | ${t('bitmax')}`;
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(Root, {
    headerVisible: headerVisible,
    children: [/*#__PURE__*/jsx_runtime_.jsx(external_next_seo_namespaceObject.DefaultSeo, {
      title: finalTitle,
      description: t('label.bitmax'),
      additionalMetaTags: configs_seo.additionalMetaTags,
      openGraph: configs_seo.openGraph,
      twitter: configs_seo.twitter
    }), settings.header.visible && /*#__PURE__*/jsx_runtime_.jsx(layout_Header, {}), /*#__PURE__*/jsx_runtime_.jsx(style_Content, {
      headerVisible: headerVisible,
      children: children
    }), settings.footer.visible && /*#__PURE__*/jsx_runtime_.jsx(layout_Footer, {})]
  });
};

/* harmony default export */ const layout_PageWrapper = (PageWrapper);
// EXTERNAL MODULE: ./i18n.js
var i18n = __webpack_require__(5558);
var i18n_default = /*#__PURE__*/__webpack_require__.n(i18n);
;// CONCATENATED MODULE: external "@mui/material/styles"
const styles_namespaceObject = require("@mui/material/styles");
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
;// CONCATENATED MODULE: external "@emotion/react"
const external_emotion_react_namespaceObject = require("@emotion/react");
;// CONCATENATED MODULE: external "@mui/material/CssBaseline"
const CssBaseline_namespaceObject = require("@mui/material/CssBaseline");
var CssBaseline_default = /*#__PURE__*/__webpack_require__.n(CssBaseline_namespaceObject);
;// CONCATENATED MODULE: ./src/theme/components.ts
const components = theme => ({
  MuiCssBaseline: {
    styleOverrides: {
      a: {
        textDecoration: 'none',
        color: 'inherit'
      },
      'input:-webkit-autofill': {
        '-webkit-box-shadow': `0 0 0px 1000px ${theme.palette.background.paper} inset !important`,
        'font-family': theme.typography.fontFamily
      },
      '::-webkit-scrollbar': {
        width: '0px !important',
        height: '0px !important'
      },

      /* Track */
      '::-webkit-scrollbar-track': {
        background: '#f1f1f1'
      },

      /* Handle */
      '::-webkit-scrollbar-thumb': {
        background: 'transparent'
      },

      /* Handle on hover */
      '::-webkit-scrollbar-thumb:hover': {
        background: '#555'
      }
    }
  },
  MuiPaper: {
    styleOverrides: {
      root: {
        boxShadow: 'none'
      }
    }
  },
  MuiFormHelperText: {
    styleOverrides: {
      root: {
        margin: '7px 0 0'
      }
    }
  },
  MuiInputBase: {
    styleOverrides: {
      root: {}
    }
  },
  MuiOutlinedInput: {
    styleOverrides: {
      notchedOutline: {
        borderColor: theme.palette.primary.main
      }
    }
  },
  MuiIconButton: {
    styleOverrides: {
      root: {
        marginLeft: -20
      }
    }
  },
  MuiButton: {
    styleOverrides: {
      root: {
        boxShadow: 'none' // backgroundColor: '#FCB400 !important',

      }
    },
    defaultProps: {
      variant: 'contained'
    }
  },
  MuiAppBar: {
    styleOverrides: {
      root: {
        background: theme.palette.background.default,
        boxShadow: '0px 1px 3px rgba(0, 0, 0, 0.05)',
        borderRadius: 0
      }
    }
  },
  MuiToggleButton: {
    styleOverrides: {
      root: {
        background: 'rgba(252, 180, 0, 0.1)',
        color: '#FCB400',
        border: 'none',
        '&.Mui-selected': {
          backgroundColor: '#FCB400',
          color: '#fff',
          '&.Mui-focusVisible': {
            backgroundColor: '#FCB400',
            color: '#fff'
          },
          '&.Mui-selected:hover': {
            background: '#FCB400'
          }
        }
      }
    }
  },
  MuiTextField: {
    styleOverrides: {
      root: {
        // input label when focused
        '& label.Mui-focused': {
          color: theme.palette.text.primary
        },
        // focused color for input with variant='standard'
        '& .MuiInput-underline:after': {
          borderBottomColor: theme.palette.text.primary
        },
        // focused color for input with variant='filled'
        '& .MuiFilledInput-underline:after': {
          borderBottomColor: theme.palette.text.primary
        },
        // focused color for input with variant='outlined'
        '& .MuiOutlinedInput-root': {
          '&.Mui-focused fieldset': {
            borderColor: theme.palette.text.primary
          }
        }
      }
    }
  },
  MuiLink: {
    styleOverrides: {
      root: {
        textDecoration: 'none'
      }
    }
  }
});

/* harmony default export */ const theme_components = (components);
;// CONCATENATED MODULE: ./src/theme/shape.ts
const shape = {
  siderWidth: 280,
  headerHeight: 64,
  bottomBarHeight: 56
};
/* harmony default export */ const theme_shape = (shape);
;// CONCATENATED MODULE: ./src/theme/typography.ts
const typography = {
  fontFamily: ['Tahoma']
};
/* harmony default export */ const theme_typography = (typography);
;// CONCATENATED MODULE: ./src/theme/configure.ts
function configure_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function configure_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { configure_ownKeys(Object(source), true).forEach(function (key) { configure_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { configure_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function configure_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

 // theme configs




 // types

const configTheme = ({
  fontFamily,
  direction,
  mode,
  responsiveFont = true
}) => {
  let theme = (0,styles_namespaceObject.createTheme)({
    direction,
    shape: theme_shape,
    palette: configure_objectSpread(configure_objectSpread(configure_objectSpread({}, palette.common), palette[mode]), {}, {
      mode
    }),
    typography: configure_objectSpread(configure_objectSpread({}, theme_typography), {}, {
      fontFamily
    })
  }); // wrap components with theme

  theme = (0,styles_namespaceObject.createTheme)(theme, {
    components: theme_components(theme)
  });

  if (responsiveFont) {
    theme = (0,styles_namespaceObject.responsiveFontSizes)(theme);
  }

  return theme;
};

/* harmony default export */ const configure = (configTheme);
;// CONCATENATED MODULE: ./src/enhancers/hooks/useThemeDetector.js

/*
	based on this article we can check user default theme
	https://medium.com/hypersphere-codes/detecting-system-theme-in-javascript-css-react-f6b961916d48
*/

const useThemeDetector = () => {
  const getCurrentTheme = () =>  false ? 0 : false;

  const {
    0: isDarkTheme,
    1: setIsDarkTheme
  } = (0,external_react_.useState)(getCurrentTheme());

  const mqListener = e => {
    setIsDarkTheme(e.matches);
  };

  (0,external_react_.useEffect)(() => {
    const darkThemeMq = window.matchMedia('(prefers-color-scheme: dark)');
    darkThemeMq.addListener(mqListener);
    return () => darkThemeMq.removeListener(mqListener);
  }, []);
  return isDarkTheme;
};

/* harmony default export */ const hooks_useThemeDetector = (useThemeDetector);
// EXTERNAL MODULE: ./src/enhancers/createEmotionCache.ts
var createEmotionCache = __webpack_require__(1503);
;// CONCATENATED MODULE: ./src/enhancers/wrappers/StyleProvider.tsx






 // Actions





 // Constants




const StyleProvider = ({
  children,
  serverEmotionCache
}) => {
  const theme = (0,external_react_redux_namespaceObject.useSelector)(state => state.app.theme);
  const isDark = hooks_useThemeDetector();
  const dispatch = useAppDispatch();
  const {
    locale
  } = (0,router_.useRouter)();
  (0,external_react_.useEffect)(() => {// dispatch(appSlice.actions.setTheme(isDark ? 'dark' : 'light'));
  }, [isDark]);
  const themeObject = (0,external_react_.useMemo)(() => {
    const {
      direction,
      fontFamily
    } = i18n.i18n.availableLocales[locale === 'fa' ? 'fa' : 'en'];

    if (false) {}

    return configure({
      direction,
      mode: theme,
      fontFamily
    });
  }, [theme, locale]);
  const emotionCache = (0,external_react_.useMemo)(() => serverEmotionCache || (0,createEmotionCache/* default */.Z)(themeObject.direction), [themeObject.direction, serverEmotionCache]);
  return /*#__PURE__*/jsx_runtime_.jsx(external_emotion_react_namespaceObject.CacheProvider, {
    value: emotionCache,
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(styles_namespaceObject.ThemeProvider, {
      theme: themeObject,
      children: [/*#__PURE__*/jsx_runtime_.jsx((CssBaseline_default()), {}), /*#__PURE__*/(0,jsx_runtime_.jsxs)((head_default()), {
        children: [/*#__PURE__*/jsx_runtime_.jsx("link", {
          href: `/fonts/${themeObject.typography.fontFamily}/style.css`,
          rel: "stylesheet"
        }), /*#__PURE__*/jsx_runtime_.jsx("link", {
          href: "/fonts/bitmax-icon/styles.css",
          rel: "stylesheet"
        })]
      }), children]
    })
  });
}; // Export default


/* harmony default export */ const wrappers_StyleProvider = (StyleProvider);
;// CONCATENATED MODULE: ./src/pages/_app.tsx
function _app_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _app_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { _app_ownKeys(Object(source), true).forEach(function (key) { _app_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { _app_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _app_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



 // import '../style/index.css';





const MyApp = props => {
  const {
    Component,
    serverEmotionCache,
    pageProps
  } = props;
  return /*#__PURE__*/jsx_runtime_.jsx(withRedux, {
    children: /*#__PURE__*/jsx_runtime_.jsx(wrappers_StyleProvider, {
      serverEmotionCache: serverEmotionCache,
      children: /*#__PURE__*/jsx_runtime_.jsx(layout_PageWrapper, {
        children: /*#__PURE__*/jsx_runtime_.jsx(Component, _app_objectSpread({}, pageProps))
      })
    })
  });
};

/* harmony default export */ const _app = ((0,external_next_i18next_.appWithTranslation)(MyApp, (i18n_default())));

/***/ }),

/***/ 1913:
/***/ ((module) => {

module.exports = require("@emotion/cache");

/***/ }),

/***/ 1480:
/***/ ((module) => {

module.exports = require("@emotion/styled");

/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 3819:
/***/ ((module) => {

module.exports = require("@mui/material/Button");

/***/ }),

/***/ 1635:
/***/ ((module) => {

module.exports = require("dayjs");

/***/ }),

/***/ 2764:
/***/ ((module) => {

module.exports = require("jalali-dayjs");

/***/ }),

/***/ 1377:
/***/ ((module) => {

module.exports = require("next-i18next");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 3195:
/***/ ((module) => {

module.exports = require("stylis-plugin-rtl");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [639,664,558,126,503], () => (__webpack_exec__(708)));
module.exports = __webpack_exports__;

})();