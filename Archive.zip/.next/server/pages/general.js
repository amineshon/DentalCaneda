"use strict";
(() => {
var exports = {};
exports.id = 504;
exports.ids = [504];
exports.modules = {

/***/ 6631:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_spring__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4417);
/* harmony import */ var react_spring__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_spring__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1480);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);





const SliderImage = ({
  src,
  alt,
  priority,
  showImage
}) => {
  const spring = (0,react_spring__WEBPACK_IMPORTED_MODULE_0__.useSpring)({
    from: {
      opacity: 0
    },
    to: {
      opacity: showImage ? 1 : 0
    },
    config: react_spring__WEBPACK_IMPORTED_MODULE_0__.config.molasses
  });
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(Amin, {
    style: spring,
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(next_image__WEBPACK_IMPORTED_MODULE_1__["default"], {
      src: src,
      alt: alt,
      layout: "fill",
      priority: priority
    })
  });
};

const Amin = _emotion_styled__WEBPACK_IMPORTED_MODULE_2___default()(react_spring__WEBPACK_IMPORTED_MODULE_0__.animated.div)`
span{

  height:70vh !important;
}

}
`;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SliderImage);

/***/ }),

/***/ 7883:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ general),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(1377);
// EXTERNAL MODULE: external "next-i18next/serverSideTranslations"
var serverSideTranslations_ = __webpack_require__(5460);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./src/components/Basic/Button/index.tsx + 2 modules
var Button = __webpack_require__(9126);
// EXTERNAL MODULE: ./src/layout/Container/index.tsx
var Container = __webpack_require__(8219);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: ./i18n.js
var i18n = __webpack_require__(5558);
var i18n_default = /*#__PURE__*/__webpack_require__.n(i18n);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./src/components/Basic/Banner/SliderImage.tsx
var SliderImage = __webpack_require__(6631);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./src/components/Basic/Banner/BannerGeneral.tsx




const BannerGeneral = () => {
  const {
    0: imageID,
    1: setImageID
  } = (0,external_react_.useState)(0);
  const images = [{
    src: '/images/GeneralPage/generaldentistry.png',
    alt: 'bg1',
    priority: true,
    showImage: imageID === 0
  }]; // useEffect(() => {
  //   const slideInterval = setInterval(() => {
  //     setImageID((imageID) => (imageID + 1) % 4);
  //   }, 10000);
  //   return () => clearInterval(slideInterval);
  // }, []);

  return images.map((image, index) => /*#__PURE__*/jsx_runtime_.jsx(SliderImage/* default */.Z, {
    src: image.src,
    alt: image.alt,
    priority: image.priority,
    showImage: image.showImage
  }, index));
};

/* harmony default export */ const Banner_BannerGeneral = (BannerGeneral);
// EXTERNAL MODULE: external "@emotion/styled"
var styled_ = __webpack_require__(1480);
var styled_default = /*#__PURE__*/__webpack_require__.n(styled_);
;// CONCATENATED MODULE: ./src/pages/general.tsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



 // constants
// Components













const General = () => {
  const {
    t
  } = (0,external_next_i18next_.useTranslation)('common');
  const {
    0: priceCur,
    1: setPriceCur
  } = (0,external_react_.useState)('irt');
  const router = (0,router_.useRouter)();
  const matches = (0,material_.useMediaQuery)(theme => theme.breakpoints.up('lg'), {
    noSsr: true
  });
  const ultraLarge = (0,material_.useMediaQuery)('(min-width:3000px)', {
    noSsr: true
  }); // test

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    children: [/*#__PURE__*/jsx_runtime_.jsx((head_default()), {
      children: /*#__PURE__*/jsx_runtime_.jsx("title", {
        children: "Dental | General Dentistry"
      })
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Box, {
      component: "div",
      children: [/*#__PURE__*/jsx_runtime_.jsx(Banner_BannerGeneral, {}), /*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
        sx: {
          height: '560px',
          position: 'absolute',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'flex-start',
          flexDirection: 'column',
          left: 0,
          right: 0,
          margin: '0 55px',
          top: '2vh'
        },
        children: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
          variant: "h3",
          sx: {
            color: '#fff',
            fontWeight: '700'
          },
          gutterBottom: true,
          component: "div",
          children: "General Dentistry"
        })
      })]
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(Container/* default */.Z, {
      sx: {
        marginTop: {
          xs: '10vh',
          md: '72vh'
        }
      },
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
        sx: {
          alignItems: 'center',
          marginBottom: '100px'
        },
        container: true,
        spacing: 2,
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
          item: true,
          xs: 12,
          md: 6,
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
            children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
              sx: {
                marginBottom: '-8%',
                color: '#DCDCDC',
                fontWeight: '900'
              },
              variant: "h1",
              gutterBottom: true,
              component: "div",
              children: "About"
            }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
              sx: {
                color: '#476B8A',
                fontWeight: '700'
              },
              variant: "h3",
              gutterBottom: true,
              component: "div",
              children: "General Dentistry"
            })]
          }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
            variant: "body1",
            gutterBottom: true,
            component: "div",
            children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ac tincidunt ultricies vitae cras. Lorem velit porta viverra facilisis lacus hac. Sed dignissim diam pretium tellus. In turpis praesent felis sed iaculis. Mi id proin risus massa est felis quam.facilisis lacus hac. Sed dignissim diam pretium tellus. In turpis praesent felis sed iaculis. Mi id proin risus massa est felis quam."
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx(GridMixPic, {
          item: true,
          xs: 12,
          md: 6,
          children: /*#__PURE__*/jsx_runtime_.jsx("img", {
            src: "/images/GeneralPage/MainPic.png",
            alt: ""
          })
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
        container: true,
        spacing: 2,
        children: /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
          item: true,
          xs: 12,
          md: 12,
          children: /*#__PURE__*/jsx_runtime_.jsx(BgBannerCenter, {
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
              sx: {
                paddingTop: '100px'
              },
              container: true,
              spacing: 2,
              children: [/*#__PURE__*/jsx_runtime_.jsx(GridAboutUsBanner, {
                item: true,
                md: 6,
                xs: 12,
                children: /*#__PURE__*/jsx_runtime_.jsx("img", {
                  src: "/images/GeneralPage/picBanner.png",
                  alt: "pic"
                })
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
                sx: {
                  textAlign: 'left'
                },
                item: true,
                md: 6,
                xs: 12,
                children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                  sx: {
                    color: '#FFF'
                  },
                  variant: "h3",
                  gutterBottom: true,
                  component: "div",
                  children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit."
                }), /*#__PURE__*/jsx_runtime_.jsx(Button/* default */.Z, {
                  sx: {
                    color: '#4060FF',
                    backgroundColor: '#fff',
                    minWidth: '160px',
                    minHeight: '45px'
                  },
                  children: 'contact US'
                })]
              })]
            })
          })
        })
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
        container: true,
        spacing: 2,
        children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
          item: true,
          md: 4,
          lg: 4,
          xs: 12,
          children: /*#__PURE__*/jsx_runtime_.jsx("img", {
            src: "/images/GeneralPage/toothextraction.png",
            alt: ""
          })
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
          item: true,
          md: 8,
          lg: 8,
          xs: 12,
          children: [/*#__PURE__*/jsx_runtime_.jsx(TypographyTittle, {
            variant: "h3",
            gutterBottom: true,
            component: "div",
            children: "Tooth Extraction"
          }), /*#__PURE__*/jsx_runtime_.jsx(Typographycontent, {
            variant: "subtitle1",
            gutterBottom: true,
            children: "our primary goal is to always save your tooth and we will make every effort to restore and repair your teeth but sometimes due to extreme conditions it is an unavoidable reality. Prior to any extraction, we will discuss the your options with you and make sure your medical history and medications are fully reviewed in advance."
          })]
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
        sx: {
          marginTop: '70px'
        },
        container: true,
        spacing: 2,
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
          item: true,
          md: 8,
          lg: 8,
          xs: 12,
          children: [/*#__PURE__*/jsx_runtime_.jsx(TypographyTittle, {
            variant: "h3",
            gutterBottom: true,
            component: "div",
            children: "Cavity prevention and treatment"
          }), /*#__PURE__*/jsx_runtime_.jsx(Typographycontent, {
            variant: "subtitle1",
            gutterBottom: true,
            children: "Regular proper brushing and flossing are essential in maintaining your dental health; however, sometimes despite your efforts to keep your teeth healthy cavities occur due to several reasons such as poor nutrition, smoking, alcohol consumption, and diabetes. Depending on you the tooth condition, we might suggest a range of treatments such as filling,crown and root canal."
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
          item: true,
          md: 4,
          lg: 4,
          xs: 12,
          children: /*#__PURE__*/jsx_runtime_.jsx("img", {
            src: "/images/GeneralPage/Cavity.png",
            alt: ""
          })
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
        sx: {
          marginTop: '70px',
          marginBottom: '100px'
        },
        container: true,
        spacing: 2,
        children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
          item: true,
          md: 4,
          lg: 4,
          xs: 12,
          children: /*#__PURE__*/jsx_runtime_.jsx("img", {
            src: "/images/GeneralPage/rootcanal.png",
            alt: ""
          })
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
          item: true,
          md: 8,
          lg: 8,
          xs: 12,
          children: [/*#__PURE__*/jsx_runtime_.jsx(TypographyTittle, {
            variant: "h3",
            gutterBottom: true,
            component: "div",
            children: "Root Canal"
          }), /*#__PURE__*/jsx_runtime_.jsx(Typographycontent, {
            variant: "subtitle1",
            gutterBottom: true,
            children: "Teeth can become damaged and infected due to severe decay, repeated dental procedures, cracks in the tooth or trauma to the face. Constant pain, swelling and tenderness of the gums, prolonged sensitivity to heat or cold and discoloration of the tooth are signs that one may need a root canal. A root canal is a procedure done to treat and save a tooth that is damaged, infected or badly decayed. The treatment involves the removal of the inflamed or infected nerves and pulp inside the tooth. That area inside the tooth is then cleaned, disinfected and sealed. After restoration, a root-canaled tooth continues to function like any other healthy tooth."
          })]
        })]
      })]
    })]
  });
};

const TypographyTittle = styled_default()(material_.Typography)`
  color: #476b8a;
  font-weight:700 ;
`;
const Typographycontent = styled_default()(material_.Typography)`
  line-height: 2.3;
  color:#343434 ;
`;
const GridMixPic = styled_default()(material_.Grid)`
  z-index: 1;
  img {
    width: 100%;
  }
`;
const BgBannerCenter = styled_default()(material_.Box)`
  background-image: url('/images/homePage/BgBannerCenter.png');
  background-size: cover;
  height: 406px;
  text-align: center;
  margin-bottom: 20%;
`;
const GridAboutUsBanner = styled_default()(material_.Grid)`
  img {
    width: 90%;
  }
`;
const getStaticProps = async ({
  locale
}) => {
  return {
    props: _objectSpread({
      locale
    }, await (0,serverSideTranslations_.serverSideTranslations)(locale, ['common'], (i18n_default())))
  };
};
/* harmony default export */ const general = (General);

/***/ }),

/***/ 1480:
/***/ ((module) => {

module.exports = require("@emotion/styled");

/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 3819:
/***/ ((module) => {

module.exports = require("@mui/material/Button");

/***/ }),

/***/ 4475:
/***/ ((module) => {

module.exports = require("@mui/material/Container");

/***/ }),

/***/ 1635:
/***/ ((module) => {

module.exports = require("dayjs");

/***/ }),

/***/ 2764:
/***/ ((module) => {

module.exports = require("jalali-dayjs");

/***/ }),

/***/ 1377:
/***/ ((module) => {

module.exports = require("next-i18next");

/***/ }),

/***/ 5460:
/***/ ((module) => {

module.exports = require("next-i18next/serverSideTranslations");

/***/ }),

/***/ 8028:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3018:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 4417:
/***/ ((module) => {

module.exports = require("react-spring");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [639,675,558,126,219], () => (__webpack_exec__(7883)));
module.exports = __webpack_exports__;

})();