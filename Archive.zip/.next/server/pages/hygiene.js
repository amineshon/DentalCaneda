"use strict";
(() => {
var exports = {};
exports.id = 418;
exports.ids = [418];
exports.modules = {

/***/ 6631:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_spring__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4417);
/* harmony import */ var react_spring__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_spring__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1480);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);





const SliderImage = ({
  src,
  alt,
  priority,
  showImage
}) => {
  const spring = (0,react_spring__WEBPACK_IMPORTED_MODULE_0__.useSpring)({
    from: {
      opacity: 0
    },
    to: {
      opacity: showImage ? 1 : 0
    },
    config: react_spring__WEBPACK_IMPORTED_MODULE_0__.config.molasses
  });
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(Amin, {
    style: spring,
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(next_image__WEBPACK_IMPORTED_MODULE_1__["default"], {
      src: src,
      alt: alt,
      layout: "fill",
      priority: priority
    })
  });
};

const Amin = _emotion_styled__WEBPACK_IMPORTED_MODULE_2___default()(react_spring__WEBPACK_IMPORTED_MODULE_0__.animated.div)`
span{

  height:70vh !important;
}

}
`;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SliderImage);

/***/ }),

/***/ 7067:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ pages_hygiene),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(1377);
// EXTERNAL MODULE: external "next-i18next/serverSideTranslations"
var serverSideTranslations_ = __webpack_require__(5460);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./src/components/Basic/Button/index.tsx + 2 modules
var Button = __webpack_require__(9126);
// EXTERNAL MODULE: ./src/layout/Container/index.tsx
var Container = __webpack_require__(8219);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: ./i18n.js
var i18n = __webpack_require__(5558);
var i18n_default = /*#__PURE__*/__webpack_require__.n(i18n);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./src/components/Basic/Banner/SliderImage.tsx
var SliderImage = __webpack_require__(6631);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./src/components/Basic/Banner/BannerHygiene.tsx




const BannerHygiene = () => {
  const {
    0: imageID,
    1: setImageID
  } = (0,external_react_.useState)(0);
  const images = [{
    src: '/images/HygienePage/dentalhygiene.png',
    alt: 'bg1',
    priority: true,
    showImage: imageID === 0
  }]; // useEffect(() => {
  //   const slideInterval = setInterval(() => {
  //     setImageID((imageID) => (imageID + 1) % 4);
  //   }, 10000);
  //   return () => clearInterval(slideInterval);
  // }, []);

  return images.map((image, index) => /*#__PURE__*/jsx_runtime_.jsx(SliderImage/* default */.Z, {
    src: image.src,
    alt: image.alt,
    priority: image.priority,
    showImage: image.showImage
  }, index));
};

/* harmony default export */ const Banner_BannerHygiene = (BannerHygiene);
// EXTERNAL MODULE: external "@emotion/styled"
var styled_ = __webpack_require__(1480);
var styled_default = /*#__PURE__*/__webpack_require__.n(styled_);
;// CONCATENATED MODULE: ./src/pages/hygiene.tsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



 // constants
// Components













const hygiene = () => {
  const {
    t
  } = (0,external_next_i18next_.useTranslation)('common');
  const {
    0: priceCur,
    1: setPriceCur
  } = (0,external_react_.useState)('irt');
  const router = (0,router_.useRouter)();
  const matches = (0,material_.useMediaQuery)(theme => theme.breakpoints.up('lg'), {
    noSsr: true
  });
  const ultraLarge = (0,material_.useMediaQuery)('(min-width:3000px)', {
    noSsr: true
  }); // test

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    children: [/*#__PURE__*/jsx_runtime_.jsx((head_default()), {
      children: /*#__PURE__*/jsx_runtime_.jsx("title", {
        children: "Dental | hygiene page"
      })
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Box, {
      component: "div",
      children: [/*#__PURE__*/jsx_runtime_.jsx(Banner_BannerHygiene, {}), /*#__PURE__*/jsx_runtime_.jsx(material_.Box, {
        sx: {
          height: '560px',
          position: 'absolute',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'flex-start',
          flexDirection: 'column',
          left: 0,
          right: 0,
          margin: '0 55px',
          top: '2vh'
        },
        children: /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
          variant: "h3",
          sx: {
            color: '#fff',
            fontWeight: '700'
          },
          gutterBottom: true,
          component: "div",
          children: "Dental Hygiene"
        })
      })]
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(Container/* default */.Z, {
      sx: {
        marginTop: {
          xs: '10vh',
          md: '72vh'
        }
      },
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
        sx: {
          alignItems: 'center',
          marginBottom: '100px'
        },
        container: true,
        spacing: 2,
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
          item: true,
          xs: 12,
          md: 6,
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
            children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
              sx: {
                marginBottom: '-8%',
                color: '#DCDCDC',
                fontWeight: '900'
              },
              variant: "h1",
              gutterBottom: true,
              children: "About"
            }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
              sx: {
                color: '#476B8A',
                fontWeight: '700'
              },
              variant: "h3",
              gutterBottom: true,
              component: "div",
              children: "Dental Hygiene"
            })]
          }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
            variant: "body1",
            gutterBottom: true,
            component: "div",
            children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ac tincidunt ultricies vitae cras. Lorem velit porta viverra facilisis lacus hac. Sed dignissim diam pretium tellus. In turpis praesent felis sed iaculis. Mi id proin risus massa est felis quam.facilisis lacus hac. Sed dignissim diam pretium tellus. In turpis praesent felis sed iaculis. Mi id proin risus massa est felis quam."
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx(GridMixPic, {
          item: true,
          xs: 12,
          md: 6,
          children: /*#__PURE__*/jsx_runtime_.jsx("img", {
            src: "/images/HygienePage/minPic.png",
            alt: ""
          })
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
        container: true,
        spacing: 2,
        children: /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
          item: true,
          xs: 12,
          md: 12,
          children: /*#__PURE__*/jsx_runtime_.jsx(BgBannerCenter, {
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
              sx: {
                paddingTop: '100px'
              },
              container: true,
              spacing: 2,
              children: [/*#__PURE__*/jsx_runtime_.jsx(GridAboutUsBanner, {
                item: true,
                md: 6,
                xs: 12,
                children: /*#__PURE__*/jsx_runtime_.jsx("img", {
                  src: "/images/HygienePage/BannerCenter.png",
                  alt: "pic"
                })
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
                sx: {
                  textAlign: 'left'
                },
                item: true,
                md: 6,
                xs: 12,
                children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                  sx: {
                    color: '#FFF',
                    fontWeight: '700'
                  },
                  variant: "h4",
                  gutterBottom: true,
                  component: "div",
                  children: "Don\u2019t Worry About Your Payment."
                }), /*#__PURE__*/jsx_runtime_.jsx(material_.Typography, {
                  sx: {
                    color: '#FFF',
                    fontWeight: '700'
                  },
                  variant: "h6",
                  gutterBottom: true,
                  component: "div",
                  children: "You Can Pay With Credit Cards, Cash Or Personla Cheques."
                }), /*#__PURE__*/jsx_runtime_.jsx(Button/* default */.Z, {
                  sx: {
                    color: '#4060FF',
                    backgroundColor: '#fff',
                    minWidth: '160px',
                    minHeight: '45px'
                  },
                  children: 'contact US'
                })]
              })]
            })
          })
        })
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
        container: true,
        spacing: 2,
        children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
          item: true,
          md: 4,
          lg: 4,
          xs: 12,
          children: /*#__PURE__*/jsx_runtime_.jsx("img", {
            src: "/images/HygienePage/scalling.png",
            alt: ""
          })
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
          item: true,
          md: 8,
          lg: 8,
          xs: 12,
          children: [/*#__PURE__*/jsx_runtime_.jsx(TypographyTittle, {
            variant: "h3",
            gutterBottom: true,
            component: "div",
            children: "Scalling"
          }), /*#__PURE__*/jsx_runtime_.jsx(Typographycontent, {
            variant: "subtitle1",
            gutterBottom: true,
            children: "If plaque and tartar is left on the teeth, it provides the right conditions for bacteria to thrive. The bacteria irritate the gums, which means that they bleed more easily. You may notice this if you are brushing your teeth, or eating, and sometimes your gums may bleed a bit. This is the early stage of gum disease called gingivitis. If you have gingivitis, we will clean your teeth by scaling and polishing them. We may also recommend an antiseptic mouthwash containing Chlorhexidine, and show you how to brush and floss your teeth effectively. Most adults have some degree of gum disease. If gingivitis not treated and nothing is done about it, the inflammation will work its way down towards the foundations of the tooth causing a \u201Cperiodontal pocket\u201D. Again, within the confines of the pocket, the conditions are such that the bacteria can have a right old party, and cause more damage. Through out the scaling procedure we will remove the built-up tartar completely, and you will feel silky smooth surface on your teeth in the end."
          })]
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
        sx: {
          marginTop: '70px'
        },
        container: true,
        spacing: 2,
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
          item: true,
          md: 8,
          lg: 8,
          xs: 12,
          children: [/*#__PURE__*/jsx_runtime_.jsx(TypographyTittle, {
            variant: "h3",
            gutterBottom: true,
            component: "div",
            children: "Whitening"
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(Typographycontent, {
            variant: "subtitle1",
            gutterBottom: true,
            children: ["Everybody loves a bright white smile, and there are a variety of products and procedures available to help you improve the look of yours.", /*#__PURE__*/jsx_runtime_.jsx("br", {}), /*#__PURE__*/jsx_runtime_.jsx("br", {}), "Many people are satisfied with the sparkle they get from brushing twice daily with a fluoride-containing toothpaste, cleaning between their teeth once a day and the regular cleanings at your dentist\u2019s office. If you decide you would like to go beyond this to make your smile look brighter, we can help you by offering you different affordable and effective approaches. We can help you choose a whitening procedure that would be more effective for you. If you are a candidate for bleaching, we may suggest a procedure that can be done in our office or we might even offer and provide you with several types of products that can be safely used at home to achieve stunning results."]
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
          item: true,
          md: 4,
          lg: 4,
          xs: 12,
          children: /*#__PURE__*/jsx_runtime_.jsx("img", {
            src: "/images/HygienePage/whitening.png",
            alt: ""
          })
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
        sx: {
          marginTop: '70px'
        },
        container: true,
        spacing: 2,
        children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
          item: true,
          md: 4,
          lg: 4,
          xs: 12,
          children: /*#__PURE__*/jsx_runtime_.jsx("img", {
            src: "/images/HygienePage/Desensitization.png",
            alt: ""
          })
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
          item: true,
          md: 8,
          lg: 8,
          xs: 12,
          children: [/*#__PURE__*/jsx_runtime_.jsx(TypographyTittle, {
            variant: "h3",
            gutterBottom: true,
            component: "div",
            children: "Desensitization"
          }), /*#__PURE__*/jsx_runtime_.jsx(Typographycontent, {
            variant: "subtitle1",
            gutterBottom: true,
            children: "Teeth can be sensitive to a number of things including hot or cold, touch, or sweets. These can generally be grouped into a hypersensitive situation of the tooth root. When the gums recede the root is exposed and under certain conditions may become sensitive. Desensitization uses techniques to protect the tooth root from these stimuli."
          }), /*#__PURE__*/jsx_runtime_.jsx(Typographycontent, {
            variant: "subtitle1",
            gutterBottom: true,
            children: "Our office has new \u2018needle-less\u201D procedures that apply a topical anesthetic to the teeth that may reduce or eliminate tooth sensitivity during scaling and root planing procedures. You can decrease tooth sensitivity with:"
          }), /*#__PURE__*/jsx_runtime_.jsx(Typographycontent, {
            variant: "subtitle1",
            gutterBottom: true,
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("ul", {
              children: [/*#__PURE__*/jsx_runtime_.jsx("li", {
                children: "Brush gently with a soft toothbrush twice/day using a low abrasion desensitizing toothpaste"
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
                children: [' ', "Having professional tooth cleaning, oral hygiene instructions and fluoride treatments."]
              }), /*#__PURE__*/jsx_runtime_.jsx("li", {
                children: "Avoid highly acidic foods like citrus or soda pop that can work against the sensitivity toothpaste"
              })]
            })
          })]
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
        sx: {
          marginTop: '70px'
        },
        container: true,
        spacing: 2,
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
          item: true,
          md: 8,
          lg: 8,
          xs: 12,
          children: [/*#__PURE__*/jsx_runtime_.jsx(TypographyTittle, {
            variant: "h3",
            gutterBottom: true,
            component: "div",
            children: "Sealants"
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(Typographycontent, {
            variant: "subtitle1",
            gutterBottom: true,
            children: ["Although thorough brushing and flossing can remove food particles and plaque from smooth surfaces of teeth, they cannot always get into all the nooks and crannies of the back teeth to remove the food and plaque. Sealants protect these vulnerable areas from tooth decay by \"sealing out\" plaque and food.", /*#__PURE__*/jsx_runtime_.jsx("br", {}), /*#__PURE__*/jsx_runtime_.jsx("br", {}), "Sealants are a thin, plastic coating painted on the chewing surfaces of teeth -- usually the back teeth (the premolars, and molars) -- to prevent tooth decay. The painted on liquid sealant quickly bonds into the depressions and grooves of the teeth forming a protective shield over the enamel of each tooth. Sealants can protect the teeth from decay for up to 10 years, but they need to be checked for chipping or wearing at regular dental check-ups and can be replaced if necessary"]
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
          item: true,
          md: 4,
          lg: 4,
          xs: 12,
          children: /*#__PURE__*/jsx_runtime_.jsx("img", {
            src: "/images/HygienePage/sealants.png",
            alt: ""
          })
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
        sx: {
          marginTop: '70px'
        },
        container: true,
        spacing: 2,
        children: [/*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
          item: true,
          md: 4,
          lg: 4,
          xs: 12,
          children: /*#__PURE__*/jsx_runtime_.jsx("img", {
            src: "/images/HygienePage/flouridetreatment.png",
            alt: ""
          })
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
          item: true,
          md: 8,
          lg: 8,
          xs: 12,
          children: [/*#__PURE__*/jsx_runtime_.jsx(TypographyTittle, {
            variant: "h3",
            gutterBottom: true,
            component: "div",
            children: "Flouride treatment"
          }), /*#__PURE__*/jsx_runtime_.jsx(Typographycontent, {
            variant: "subtitle1",
            gutterBottom: true,
            children: "Tooth decay is caused by acid-producing bacteria that collect around the teeth and gingivae (gums) in a sticky, clear film called \u201Cplaque.\u201D Brushing twice a day and cleaning between teeth with floss or another type of inter- dental cleaner help remove plaque. Regular dental examinations and cleanings also are important for keeping teeth healthy."
          }), /*#__PURE__*/jsx_runtime_.jsx(Typographycontent, {
            variant: "subtitle1",
            gutterBottom: true,
            children: "If you, or a family member, are at a moderate-to- high risk of developing caries, our professional fluo-ride treatment can help."
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(Typographycontent, {
            variant: "subtitle1",
            gutterBottom: true,
            children: ["Professional fluoride treatments generally take just a few minutes. The fluoride may be in the form of a solution, gel, foam or varnish. Typically, it is applied with a cotton swab or brush, or it is used as a rinse or placed in a tray that is held in the mouth for several minutes.", /*#__PURE__*/jsx_runtime_.jsx("br", {}), "Depending on your oral health status, fluoride treatments may be recommended every three, six or 12 months."]
          })]
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
        sx: {
          marginTop: '70px',
          marginBottom: '100px'
        },
        container: true,
        spacing: 2,
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Grid, {
          item: true,
          md: 8,
          lg: 8,
          xs: 12,
          children: [/*#__PURE__*/jsx_runtime_.jsx(TypographyTittle, {
            variant: "h3",
            gutterBottom: true,
            component: "div",
            children: "Oral cancer screening"
          }), /*#__PURE__*/jsx_runtime_.jsx(Typographycontent, {
            variant: "subtitle1",
            gutterBottom: true,
            children: "Oral cancer screening (OCS) may be the best way to detect oral cancer early, and dental hygienists have an important role. They screen for oral cancer as part of every dental hygiene appointment, regardless of age, and educate clients about risk factors and how to detect potential problems. Detecting the disease in the early stages is key to the survival rate. Thousands of new cases of oral cancer are diagnosed in Canada each year; the five-year survival rate of all oral cancer cases is about 50 per cent. Some estimates suggest that screening could detect as many as 80 per cent of new cases."
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx(material_.Grid, {
          item: true,
          md: 4,
          lg: 4,
          xs: 12,
          children: /*#__PURE__*/jsx_runtime_.jsx("img", {
            src: "/images/HygienePage/oralcancerscreeni.png",
            alt: ""
          })
        })]
      })]
    })]
  });
};

const TypographyTittle = styled_default()(material_.Typography)`
  color: #476b8a;
  font-weight:700 ;
`;
const Typographycontent = styled_default()(material_.Typography)`
  line-height: 2.3;
  color:#343434 ;
`;
const GridMixPic = styled_default()(material_.Grid)`
  z-index: 1;
  img {
    width: 100%;
  }
`;
const BgBannerCenter = styled_default()(material_.Box)`
  background-image: url('/images/homePage/BgBannerCenter.png');
  background-size: cover;
  height: 406px;
  text-align: center;
  margin-bottom: 20%;
`;
const GridAboutUsBanner = styled_default()(material_.Grid)`
  img {
    width: 90%;
  }
`;
const getStaticProps = async ({
  locale
}) => {
  return {
    props: _objectSpread({
      locale
    }, await (0,serverSideTranslations_.serverSideTranslations)(locale, ['common'], (i18n_default())))
  };
};
/* harmony default export */ const pages_hygiene = (hygiene);

/***/ }),

/***/ 1480:
/***/ ((module) => {

module.exports = require("@emotion/styled");

/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 3819:
/***/ ((module) => {

module.exports = require("@mui/material/Button");

/***/ }),

/***/ 4475:
/***/ ((module) => {

module.exports = require("@mui/material/Container");

/***/ }),

/***/ 1635:
/***/ ((module) => {

module.exports = require("dayjs");

/***/ }),

/***/ 2764:
/***/ ((module) => {

module.exports = require("jalali-dayjs");

/***/ }),

/***/ 1377:
/***/ ((module) => {

module.exports = require("next-i18next");

/***/ }),

/***/ 5460:
/***/ ((module) => {

module.exports = require("next-i18next/serverSideTranslations");

/***/ }),

/***/ 8028:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3018:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 4417:
/***/ ((module) => {

module.exports = require("react-spring");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [639,675,558,126,219], () => (__webpack_exec__(7067)));
module.exports = __webpack_exports__;

})();