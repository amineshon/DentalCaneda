exports.id = 558;
exports.ids = [558];
exports.modules = {

/***/ 5558:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

const dayjs = __webpack_require__(1635);

const jalaliday = __webpack_require__(2764);

dayjs.extend(jalaliday);
const numbers = {
  fa: ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'],
  ar: ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩']
};

const formatNumber = (value, lang, options = {}) => {
  if (!value) return '';
  let newValue = value; // show decimals

  if (options.fraction) {
    newValue = newValue.toFixed(options.fraction);
  } // add comma to number


  if (options.comma) {
    const parts = newValue.toString().split('.');
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    newValue = parts.join('.');
  } // convert fa number


  if (lang === 'fa' || lang === 'ar') {
    newValue = newValue.toString().replace(/\d/g, digit => numbers[lang][digit]);
  }

  if (options.unit) {
    newValue += ` ${options.unit}`;
  }

  return newValue;
};

const formatDatetime = (value, lang, options = {
  toFormat: 'YYYY-MM-DD'
}) => {
  const date = dayjs(value, options.fromFormat);
  const d = date.locale(lang).format(options.toFormat);
  return lang === 'fa' ? formatNumber(d, lang) : d;
};

module.exports = {
  i18n: {
    defaultLocale: 'fa',
    locales: ['fa', 'en'],
    localeDetection: false,
    // custom config
    availableLocales: {
      fa: {
        key: 'fa',
        label: 'French ',
        direction: 'ltr',
        fontFamily: 'Peyda'
      },
      en: {
        key: 'en',
        label: 'English',
        direction: 'ltr',
        fontFamily: 'AirbnbCerealApp'
      }
    }
  },
  serializeConfig: false,
  reloadOnPrerender: true,
  interpolation: {
    format: (value, format, lang, options) => {
      let newOptions = _objectSpread({}, options);

      const splittedFormat = format.replace(')', '').split('(');
      const newFormat = splittedFormat[0];
      const optionsFromFormat = splittedFormat[1];

      if (optionsFromFormat) {
        const keyValuePair = optionsFromFormat.split(',');
        keyValuePair.forEach(item => {
          const keyValue = item.split(':');
          const k = keyValue[0].trim();
          const v = keyValue[1].replace(/'/g, '').trim();
          newOptions = _objectSpread({
            [k]: v
          }, newOptions);
        });
      }

      if (newFormat === 'number') {
        return formatNumber(value, options.lang || lang, newOptions);
      }

      if (newFormat === 'datetime') {
        return formatDatetime(value, options.lang || lang, newOptions);
      }

      return value;
    }
  }
};

/***/ })

};
;