"use strict";
exports.id = 503;
exports.ids = [503];
exports.modules = {

/***/ 1503:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _emotion_cache__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1913);
/* harmony import */ var _emotion_cache__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_emotion_cache__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var stylis_plugin_rtl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3195);
/* harmony import */ var stylis_plugin_rtl__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(stylis_plugin_rtl__WEBPACK_IMPORTED_MODULE_1__);
// import createCache from '@emotion/cache';
// // prepend: true moves MUI styles to the top of the <head> so they're loaded first.
// /*
// 	It allows developers to easily override MUI styles
// 	with other styling solutions, like CSS modules.
// */
// export default function createEmotionCache() {
// 	return createCache({ key: 'css-ltr', prepend: true });
// }



// prepend: true moves MUI styles to the top of the <head> so they're loaded first.

/*
	It allows developers to easily override MUI styles
	with other styling solutions, like CSS modules.
*/
const createEmotionCache = (direction = 'ltr') => {
  const stylisPlugins = [];

  if (direction === 'rtl') {
    stylisPlugins.push((stylis_plugin_rtl__WEBPACK_IMPORTED_MODULE_1___default()));
  }

  return _emotion_cache__WEBPACK_IMPORTED_MODULE_0___default()({
    key: `css-${direction}`,
    prepend: true,
    stylisPlugins
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (createEmotionCache);

/***/ })

};
;