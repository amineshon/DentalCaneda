"use strict";
exports.id = 103;
exports.ids = [103];
exports.modules = {

/***/ 4103:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _SliderImage__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6631);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);




const Banner = () => {
  const {
    0: imageID,
    1: setImageID
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
  const images = [{
    src: '/images/homePage/top.png',
    alt: 'bg1',
    priority: true,
    showImage: imageID === 0
  }]; // useEffect(() => {
  //   const slideInterval = setInterval(() => {
  //     setImageID((imageID) => (imageID + 1) % 4);
  //   }, 10000);
  //   return () => clearInterval(slideInterval);
  // }, []);

  return images.map((image, index) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(_SliderImage__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
    src: image.src,
    alt: image.alt,
    priority: image.priority,
    showImage: image.showImage
  }, index));
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Banner);

/***/ }),

/***/ 6631:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_spring__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4417);
/* harmony import */ var react_spring__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_spring__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1480);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);





const SliderImage = ({
  src,
  alt,
  priority,
  showImage
}) => {
  const spring = (0,react_spring__WEBPACK_IMPORTED_MODULE_0__.useSpring)({
    from: {
      opacity: 0
    },
    to: {
      opacity: showImage ? 1 : 0
    },
    config: react_spring__WEBPACK_IMPORTED_MODULE_0__.config.molasses
  });
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(Amin, {
    style: spring,
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(next_image__WEBPACK_IMPORTED_MODULE_1__["default"], {
      src: src,
      alt: alt,
      layout: "fill",
      priority: priority
    })
  });
};

const Amin = _emotion_styled__WEBPACK_IMPORTED_MODULE_2___default()(react_spring__WEBPACK_IMPORTED_MODULE_0__.animated.div)`
span{

  height:70vh !important;
}

}
`;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SliderImage);

/***/ })

};
;