"use strict";
exports.id = 126;
exports.ids = [126];
exports.modules = {

/***/ 9126:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Basic_Button)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "@mui/material/Button"
var Button_ = __webpack_require__(3819);
var Button_default = /*#__PURE__*/__webpack_require__.n(Button_);
// EXTERNAL MODULE: external "@emotion/styled"
var styled_ = __webpack_require__(1480);
var styled_default = /*#__PURE__*/__webpack_require__.n(styled_);
;// CONCATENATED MODULE: ./src/components/Basic/LoadingIndicator/style.ts

const Spinner = (styled_default()).div`
  ${p => `
		width: ${p.size}px;
		height: ${p.size}px;
	`}

  svg {
    animation: rotate 2s linear infinite;

    circle {
      ${p => `stroke: ${p.theme.palette[p.color] ? p.theme.palette[p.color].main : p.color}`}
      stroke-linecap: round;
      animation: dash 1.4s ease-in-out infinite;
    }
  }

  @keyframes rotate {
    100% {
      transform: rotate(360deg);
    }
  }

  @keyframes dash {
    0% {
      stroke-dasharray: 1, 150;
      stroke-dashoffset: 0;
    }
    50% {
      stroke-dasharray: 90, 150;
      stroke-dashoffset: -35;
    }
    100% {
      stroke-dasharray: 90, 150;
      stroke-dashoffset: -124;
    }
  }
`;
const Dots = (styled_default()).div`
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 24px;

  > div {
    border-radius: 50%;
    margin: 0 4px;
    animation-name: loading-dots;
    animation-duration: 0.4s;
    animation-timing-function: ease;
    animation-iteration-count: infinite;
    animation-direction: alternate-reverse;

    &:nth-child(1) {
      animation-delay: 0s;
    }
    &:nth-child(2) {
      animation-delay: 0.1s;
    }
    &:nth-child(3) {
      animation-delay: 0.2s;
    }

    ${p => `
			width: ${p.size}px;
			height: ${p.size}px;
			background: ${p.theme.palette[p.color] ? p.theme.palette[p.color].main : p.color};
		`}
  }

  @keyframes loading-dots {
    0% {
      transform: scale(1.2);
    }
    100% {
      transform: scale(0.9);
    }
  }
`;
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./src/components/Basic/LoadingIndicator/index.tsx





const LoadingIndicator = ({
  color,
  size,
  strokeWidth,
  type
}) => {
  let finalColor = color;

  if (color === 'light') {
    finalColor = '#fff';
  } else if (color === 'dark') {
    finalColor = '#333';
  }

  if (type === 'spin') {
    return /*#__PURE__*/jsx_runtime_.jsx(Spinner, {
      color: finalColor,
      size: size,
      className: "loader",
      children: /*#__PURE__*/jsx_runtime_.jsx("svg", {
        width: "100%",
        height: "100%",
        children: /*#__PURE__*/jsx_runtime_.jsx("circle", {
          cx: size / 2,
          cy: size / 2,
          r: size / 2 - strokeWidth,
          fill: "none",
          strokeWidth: strokeWidth
        })
      })
    });
  }

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(Dots, {
    color: finalColor,
    size: size,
    className: "loader",
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {}), /*#__PURE__*/jsx_runtime_.jsx("div", {}), /*#__PURE__*/jsx_runtime_.jsx("div", {})]
  });
};

/* harmony default export */ const Basic_LoadingIndicator = (/*#__PURE__*/(0,external_react_.memo)(LoadingIndicator));
;// CONCATENATED MODULE: ./src/components/Basic/Button/index.tsx
const _excluded = ["children", "isLoading", "onClick"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }



 // Components




// Button Component
const Button = _ref => {
  let {
    children,
    isLoading = false,
    onClick
  } = _ref,
      restProps = _objectWithoutProperties(_ref, _excluded);

  return /*#__PURE__*/jsx_runtime_.jsx(MaterialButtonEdit, _objectSpread(_objectSpread({
    sx: {
      backgroundColor: '#6875F7',
      minWidth: '160px',
      minHeight: '45px',
      fontWeight: '700'
    }
  }, restProps), {}, {
    onClick: onClick,
    disabled: isLoading || restProps.disabled,
    children: isLoading ? /*#__PURE__*/jsx_runtime_.jsx(Basic_LoadingIndicator, {
      size: 8,
      color: "light"
    }) : children
  }));
};

const MaterialButtonEdit = styled_default()((Button_default()))`
border-radius: 5px;

:hover{
  background-color: #4F5FFF;
}
`;
/* harmony default export */ const Basic_Button = (Button);

/***/ })

};
;