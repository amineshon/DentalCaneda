export { default as apiConfig } from './api';
export { default as appConfig } from './app';
export { default as seoConfig } from './seo';
export {
	route as routeConfig,
	setting as routeSetting,
} from './route';
