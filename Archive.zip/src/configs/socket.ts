/* eslint-disable key-spacing */

interface Socket {
	[socketChanel: string]: {

		/*
			chanel name of the socket
		*/
		chanel: string;

	};
}

const socket: Socket = {

};

export default socket;
