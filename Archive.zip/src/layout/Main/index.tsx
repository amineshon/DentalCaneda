import React from 'react';

// Component
const Main = ({ children }) => (
	children
);

export default Main;
