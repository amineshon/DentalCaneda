export const SOCIAL = [
  {
    KEY: 'aparat',
    URL: '#',
    ICON: '/images/icon/social/aparat.svg',
    DARK_ICON: '/images/icon/social/aparat-dark.svg',
  },
  {
    KEY: 'linkedIn',
    URL: '#',
    ICON: '/images/icon/social/linkedin.svg',
    DARK_ICON: '/images/icon/social/linkedin-dark.svg',
  },
  {
    KEY: 'instagram',
    URL: '#',
    ICON: '/images/icon/social/instagram.svg',
    DARK_ICON: '/images/icon/social/instagram-dark.svg',
  },
  {
    KEY: 'twitter',
    URL: '#',
    ICON: '/images/icon/social/twitter.svg',
    DARK_ICON: '/images/icon/social/twitter-dark.svg',
  },
];
