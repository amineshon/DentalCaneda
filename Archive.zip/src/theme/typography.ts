const typography = {
	fontFamily: ['Tahoma'],
};

export default typography;
