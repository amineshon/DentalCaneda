const shape = {
  siderWidth: 280,
  headerHeight: 64,
  bottomBarHeight: 56,
};

export default shape;
