import common from './common';
import light from './light';
import dark from './dark';

export default {
	common,
	light,
	dark,
};
